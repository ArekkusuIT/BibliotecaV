#include "libro.h"


Libro::Libro (unsigned int identifier,
             std::string titolo,
             int AnnoPub,
             std::string descrizione,
             Enums::MediaGenre genere,
             std::string image_path,
             int pagine,
             std::string editore,
             std::string autore,
             std::string ISBN,
             Enums::Lingue lingua) :

    Cartaceo(identifier, titolo, AnnoPub, descrizione, genere, image_path, pagine, editore, autore), ISBN(ISBN), lingua(lingua)
{}

std::string Libro::getISBN() const{
    return ISBN;
}

Libro& Libro::setISBN(const std::string ISBN){
    this->ISBN = ISBN;
    return *this;
}

Enums::Lingue Libro::getLingua() const{
    return lingua;
}

Libro& Libro::setLingua(const Enums::Lingue lingua){
    this->lingua = lingua;
    return *this;
}
void Libro::accept(class BVisitor& v){
    v.visit(*this);
}
void Libro::accept(class BConstVisitor& v) const {
    v.visit(*this);
}

Media* Libro::clone() const {
    return new Libro(*this);
}


