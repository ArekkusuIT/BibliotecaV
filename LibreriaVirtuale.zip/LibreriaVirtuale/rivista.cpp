#include "rivista.h"

Rivista::Rivista(const unsigned int identifier,
                 std::string titolo,
                 int AnnoPub,
                 std::string descrizione,
                 Enums::MediaGenre genere,
                 std::string image_path,
                 int pagine,
                 std::string editore,
                 std::string autore,
                 Enums::Lingue lingua,
                 int NumeroSettimanale) :

    Cartaceo(identifier, titolo, AnnoPub, descrizione, genere, image_path, pagine, editore, autore), lingua(lingua), NumeroSettimanale(NumeroSettimanale)
{}

int Rivista::getNumeroSettimanale() const{
    return NumeroSettimanale;
}

Rivista& Rivista::setNumeroSettimanale(const int NumeroSettimanale){
    this->NumeroSettimanale = NumeroSettimanale;
    return *this;
}

void Rivista::accept(class BVisitor& v){
    v.visit(*this);
}
void Rivista::accept(class BConstVisitor& v) const {
    v.visit(*this);
}

Enums::Lingue Rivista::getLingua() const{
    return lingua;
}

Rivista& Rivista::setLingua(const Enums::Lingue lingua){
    this->lingua = lingua;
    return *this;
}

Media* Rivista::clone() const {
    return new Rivista(*this);
}
