#include "film.h"
#include "Enums/mediaenums.h"


Film::Film(const unsigned int identifier,
           std::string titolo,
           int AnnoPub,
           std::string descrizione,
           Enums::MediaGenre genere,
           std::string image_path,
           std::string regista,
           std::string studioProduzione,
           std::string media_path,
           Enums::AgeRating AgeRating,
           int DurataMinuti,
           Enums::VideoQuality QualitaVideo) :

    Multimedia(identifier, titolo, AnnoPub, descrizione, genere, image_path, regista, studioProduzione, media_path, AgeRating), DurataMinuti(DurataMinuti), QualitaVideo(QualitaVideo)
{}

int Film::getDurataMinuti() const{
    return DurataMinuti;
}

Film& Film::setDurataMinuti(const int DurataMinuti){
    this->DurataMinuti = DurataMinuti;
    return *this;
}

Enums::VideoQuality Film::getQualitaVideo() const{
    return QualitaVideo;
}

Film& Film::setQualitaVideo(const Enums::VideoQuality QualitaVideo){
    this->QualitaVideo = QualitaVideo;
    return *this;
}
void Film::accept(class BVisitor& v){
    v.visit(*this);
}
void Film::accept(class BConstVisitor& v) const {
    v.visit(*this);
}

Media* Film::clone() const {
    return new Film(*this);
}


