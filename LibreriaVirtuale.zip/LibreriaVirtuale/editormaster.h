#ifndef EDITORMASTER_H
#define EDITORMASTER_H

#include <QObject>
#include <QStackedWidget>
#include <QWidget>
#include <QVBoxLayout>
#include <QString>
#include <QScrollArea>
#include <QMap>
#include <QLayout>
#include "media.h"
#include "cartaceo.h"
#include "multimedia.h"
#include "Enums/mediaenums.h"


class EditorMaster: public QWidget
{
    Q_OBJECT
private:
    QStackedWidget* stack;
    QScrollArea* scrollArea;
    QWidget* scrollContent;
    QVBoxLayout* layout;
    QVBoxLayout* modifyLayout;
    QMap<QString, QWidget*> menuWidgets;
    QString image;
    QString media_path;
    const Media* mediaBeingEdited;

    void clearLayout(QLayout* layout);
    void setupDefaultInputs();

    struct MediaInfo {
        unsigned int identifier;
        QString titolo;
        int AnnoPub;
        QString descrizione;
        Enums::MediaGenre genere;
        QString image_path;
    };
    struct CartaceoInfo {
        int pagine;
        QString autore;
        QString editore;
    };

    struct MultimediaInfo {
        QString regista;
        QString studioProduzione;
            QString media_path;
        Enums::AgeRating AgeRating;
    };

public:
    explicit EditorMaster(QStackedWidget* stackWidget, QWidget* parent = nullptr);

    void setupMedia(Media* media = nullptr);
    void setupCartaceo(Cartaceo* cartaceo = nullptr);
    void setupMultimedia(Multimedia* multimedia = nullptr);
    void setupFilm(Film* film = nullptr);
    void setupSerieTV(SerieTV* serieTV = nullptr);
    void setupLibro(Libro* libro = nullptr);
    void setupRivista(Rivista* rivista = nullptr);
    MediaInfo createMedia();
    CartaceoInfo createCartaceo();
    MultimediaInfo createMultimedia();
    Libro* createLibro();
    Rivista* createRivista();
    Film* createFilm();
    SerieTV* createSerieTV();
    void save(Media* media);
    void saveCartaceo(Cartaceo* cartaceo);
    void saveMultimedia(Multimedia* multimedia);
    void saveLibro(Libro* libro);
    void saveRivista(Rivista* rivista);
    void saveFilm(Film* film);
    void saveSerieTV(SerieTV* serieTV);



signals:
    void newMedia(Media* media);
    void updateMedia(Media* media);
    void handle();
    void modificationCompleted();
    void modificationCanceled();
private slots:
    void annulla();
    void closeEditor();
    void salvaModifiche();
public slots:
    void modifyMedia(Media* media);
    void createObject();
};

#endif // EDITORMASTER_H
