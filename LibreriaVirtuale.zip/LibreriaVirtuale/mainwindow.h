#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QListWidget>
#include <QLabel>
#include <QToolBar>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonDocument>
#include "QPointer"
#include "editormaster.h"
#include "JsonManager.h"
#include "searchwidget.h"
#include "reviewservice.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    // Widgets principali
    Media* currentMedia;
    QStackedWidget* stackedWidget;
    QWidget* welcomeScreen;
    QWidget* mainScreen;
    QToolBar* toolBar;
    QMenu* fileMenu;
    QToolButton* fileToolButton;
    QAction* openMediaAction;
    QAction* saveMediaAction;
    QAction* newMediaFileAction;
    QAction* shortcutsList;
    QAction* addAction;
    ReviewService* reviewService;
    QPushButton* recensioniButton;
    QPushButton* trailerButton;
    QListWidget* mediaList;
    QLabel* mediaDetails;
    SearchWidget* searchWidget;
    QPointer<EditorMaster> editor;
    JsonManager* jsonManager;
    QList<Media*> mediaCollection;
    QList<Media*> filteredMediaCollection;
    QString jsonFilePath = "media_collection.json";
    
    void setupWelcomeScreen();
    void setupMainScreen();
    void setupToolBar();
    void loadMediaFromJson();
    void saveMediaToJson();
    void displayMediaDetails(Media* media);
    void refreshMediaList();
    void filterMediaList(const QString& searchText);
    QString getMediaType(Media* media);
    bool mediaMatchesSearch(Media* media, const QString& searchText);
    void updateFileIndicator();
    void clearMediaList();
    bool isValidJsonFile(const QString& filepath);

private slots:
    void showMainScreen();
    void onMediaItemClicked(QListWidgetItem* item);
    void onEditButtonClicked();
    void onDeleteButtonClicked();
    void handleNewMedia(Media* media);
    void handleMediaUpdate();
    void onSearchRequested(const QString& searchText);
    void onSearchCleared();
    void onDescrizioneButtonClicked();
    void onRecensioniButtonClicked();
    void onTrailerButtonClicked();
    void onMediaUpdated(Media* media);
public slots:
    void createMedia();
    void editMedia(unsigned int identifier);
    void getMediaDetails(unsigned int identifier);
    void deleteMedia(unsigned int identifier);
    void addMediaToList(const Media& media);
    void openMediaFile();
    void saveMediaFile();
    void closeEditWindow();
    void createNewMediaFile();
    void showShortcuts();
};
#endif // MAINWINDOW_H
