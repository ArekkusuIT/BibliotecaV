#ifndef BCONSTVISITOR_H
#define BCONSTVISITOR_H


class Libro;
class Rivista;
class SerieTV;
class Film;


class BConstVisitor{
public:
    virtual ~BConstVisitor() = default;
    virtual void visit(const Libro& Libro) = 0;
    virtual void visit(const Rivista& Rivista) = 0;
    virtual void visit(const SerieTV& SerieTV)  = 0;
    virtual void visit(const Film& Film) = 0;
};

#endif // BCONSTVISITOR_H
