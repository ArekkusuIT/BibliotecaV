#ifndef FILM_H
#define FILM_H

#include "multimedia.h"
#include "recensioni.h"
#include "vector"

class Film: public Multimedia
{
private:
    std::string regista;
    std::string studioProduzione;
    std::vector<Recensioni*> ratings = {};
    std::string media_path;
    Enums::AgeRating AgeRating;
    int DurataMinuti;
    Enums::VideoQuality QualitaVideo;
public:
    Film(const unsigned int identifier,
         std::string titolo,
         int AnnoPub,
         std::string descrizione,
         Enums::MediaGenre genere,
         std::string image_path,
         std::string regista,
         std::string studioProduzione,
         std::string media_path,
         Enums::AgeRating AgeRating,
         int DurataMinuti,
         Enums::VideoQuality QualitaVideo);

    Media* clone() const override;

    int getDurataMinuti() const;
    Film& setDurataMinuti(const int DurataMinuti);

    Enums::VideoQuality getQualitaVideo() const;
    Film& setQualitaVideo(const Enums::VideoQuality QualitaVideo);

    virtual void accept(class BVisitor& v) final;
    virtual void accept(class BConstVisitor& v) const final;
};

#endif // FILM_H
