#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QMovie>
#include <QTimer>
#include <QMessageBox>
#include <QFile>
#include <QDir>
#include <QAction>
#include <QSpacerItem>
#include <QToolButton>
#include "Enums/enumsconversion.h"
#include "QMenu"
#include "QFileDialog"
#include "QApplication"

#include "libro.h"
#include "rivista.h"
#include "film.h"
#include "serietv.h"
#include "JsonManager.h"
#include "recensionidialog.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), currentMedia(nullptr), reviewService(new ReviewService(this)), editor(nullptr),jsonManager(new JsonManager("media_collection.json"))
{

    // Imposta la finestra principale
    setWindowTitle("Media Library Manager");
    resize(1000, 700);
    
    stackedWidget = new QStackedWidget(this);
    setCentralWidget(stackedWidget);

    connect(reviewService, &ReviewService::recensioniPronte, this, [this](const std::vector<Recensioni>& recensioni) {
        RecensioniDialog dialog(recensioni, this);
        dialog.exec();
    });

    QFile file("media_collection.json");
    if (!file.exists()) {
        if (!file.open(QIODevice::WriteOnly)) {
            QMessageBox::critical(this, "Errore", "Impossibile creare il file JSON!");
            return;
        }
        file.write("[]");
        file.close();
    }
    

    toolBar = new QToolBar(this);


    setupWelcomeScreen();
    setupMainScreen();
    setupToolBar();
    
    addToolBar(toolBar);

    stackedWidget->setCurrentIndex(0);
    
    // Dopo 5 secondi, mostra la schermata principale
    QTimer::singleShot(5000, this, [this](){
        showMainScreen();
        loadMediaFromJson();
    });
}


MainWindow::~MainWindow()
{
    saveMediaToJson();

    qDeleteAll(mediaCollection);
    mediaCollection.clear();
    filteredMediaCollection.clear();
    currentMedia = nullptr;

    delete jsonManager;
}

void MainWindow::setupWelcomeScreen()
{
    welcomeScreen = new QWidget();
    QVBoxLayout* layout = new QVBoxLayout(welcomeScreen);

    QLabel* gifLabel = new QLabel();
    QMovie* movie = new QMovie(":/icons/Images_PAO/welcome.gif");
    if (!movie->isValid()) {
        qWarning() << "GIF not found! Using placeholder";
        delete movie;
        movie = nullptr;
        gifLabel->setText("Welcome to Media Library");
    } else {
        gifLabel->setMovie(movie);

        gifLabel->setAlignment(Qt::AlignCenter);

        movie->start();
    }
    
    QLabel* welcomeLabel = new QLabel("Benvenuto nella Media Library!");
    welcomeLabel->setAlignment(Qt::AlignCenter);
    QFont font = welcomeLabel->font();
    font.setPointSize(20);
    font.setBold(true);
    welcomeLabel->setFont(font);
    
    layout->addWidget(gifLabel);
    layout->addWidget(welcomeLabel);
    
    stackedWidget->addWidget(welcomeScreen);
}

void MainWindow::setupMainScreen()
{
    mainScreen = new QWidget();
    QHBoxLayout* mainLayout = new QHBoxLayout(mainScreen);

    
    QWidget* leftPanel = new QWidget();
    leftPanel->setFixedWidth(300);
    QVBoxLayout* leftLayout = new QVBoxLayout(leftPanel);

    searchWidget = new SearchWidget();
    leftLayout->addWidget(searchWidget);
    
    QLabel* listTitle = new QLabel("I tuoi Media");
    QFont titleFont = listTitle->font();
    titleFont.setPointSize(16);
    titleFont.setBold(true);
    listTitle->setFont(titleFont);
    
    mediaList = new QListWidget();
    mediaList->setIconSize(QSize(32, 32));
    
    leftLayout->addWidget(listTitle);
    leftLayout->addWidget(mediaList);
    
    QWidget* rightPanel = new QWidget();
    QVBoxLayout* rightLayout = new QVBoxLayout(rightPanel);
    
    mediaDetails = new QLabel("Seleziona un media per visualizzare i dettagli");
    mediaDetails->setWordWrap(true);
    mediaDetails->setAlignment(Qt::AlignTop);
    
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    QPushButton* editButton = new QPushButton("Modifica");
    QPushButton* deleteButton = new QPushButton("Elimina");
    recensioniButton = new QPushButton("Recensioni");
    trailerButton = new QPushButton("Trailer");

    buttonLayout->addWidget(recensioniButton);
    buttonLayout->addWidget(trailerButton);
    buttonLayout->addWidget(editButton);
    buttonLayout->addWidget(deleteButton);

    recensioniButton->setEnabled(false);
    trailerButton->setEnabled(false);
    
    rightLayout->addWidget(mediaDetails);
    rightLayout->addLayout(buttonLayout);
    rightLayout->addStretch();
    
    mainLayout->addWidget(leftPanel);
    mainLayout->addWidget(rightPanel);
    
    stackedWidget->addWidget(mainScreen);
    
    connect(mediaList, &QListWidget::itemClicked, this, &MainWindow::onMediaItemClicked);
    connect(editButton, &QPushButton::clicked, this, &MainWindow::onEditButtonClicked);
    connect(deleteButton, &QPushButton::clicked, this, &MainWindow::onDeleteButtonClicked);
    connect(searchWidget, &SearchWidget::searchRequested, this, &MainWindow::onSearchRequested);
    connect(searchWidget, &SearchWidget::searchCleared, this, &MainWindow::onSearchCleared);
    connect(recensioniButton, &QPushButton::clicked, this, &MainWindow::onRecensioniButtonClicked);
    connect(trailerButton, &QPushButton::clicked, this, &MainWindow::onTrailerButtonClicked);
}


void MainWindow::clearMediaList()
{
    while (mediaList->count() > 0) {
        QListWidgetItem* item = mediaList->takeItem(0);
        delete item;
    }
}

void MainWindow::updateFileIndicator()
{
    // Trova e aggiorna l'indicatore del file nella toolbar
    for (QLabel* label : toolBar->findChildren<QLabel*>()) {
        if (label->objectName() == "fileIndicator") {
            label->setText("File: " + (jsonFilePath.isEmpty() ? "Nessuno" : QFileInfo(jsonFilePath).fileName()));
            break;
        }
    }
}

void MainWindow::setupToolBar()
{
    fileMenu = new QMenu();

    fileToolButton = new QToolButton(this);
    fileToolButton->setText("File");
    fileToolButton->setPopupMode(QToolButton::MenuButtonPopup);
    fileToolButton->setStyleSheet("QToolButton::menu-indicator { image: none; }");
    fileToolButton->setIcon(QIcon(":/icons/Images_PAO/file_icon.png"));
    fileToolButton->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

    addAction = new QAction(QIcon(":/icons/Images_PAO/new_media_icon.png"), "Create Media");
    openMediaAction = new QAction(QIcon(":/icons/Images_PAO/open_file_icon.png"), "Open Media File");
    saveMediaAction = new QAction(QIcon(":/icons/Images_PAO/save_icon.png"), "Save Media File");
    newMediaFileAction = new QAction(QIcon(":/icons/Images_PAO/new_file_icon.png"), "New Media File");
    shortcutsList = new QAction(QIcon(":/icons/Images_PAO/info_icon.png"), "Shortcuts");

    QAction* saveCurrentAction = new QAction(QIcon(":/icons/Images_PAO/save_icon.png"), "Salva nel file corrente");
    saveCurrentAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_S));

    // Aggiungi alla toolbar e al menu
    toolBar->addAction(saveCurrentAction);
    fileMenu->addAction(saveCurrentAction);

    // Connessione del segnale
    connect(saveCurrentAction, &QAction::triggered, this, [this]() {
        if (jsonFilePath.isEmpty()) {
            QMessageBox::warning(this, "Attenzione", "Nessun file aperto. Apri o crea un file prima di salvare.");
            return;
        }
        saveMediaToJson();
        QMessageBox::information(this, "Successo", "Media salvati nel file: " + jsonFilePath);
    });


    fileMenu->addAction(addAction);
    fileMenu->addAction(openMediaAction);
    fileMenu->addAction(saveMediaAction);
    fileMenu->addAction(newMediaFileAction);
    fileMenu->addAction(shortcutsList);
    fileMenu->addSeparator();
    fileToolButton->setMenu(fileMenu);

    addAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_N));
    openMediaAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_O));
    saveMediaAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_S));
    newMediaFileAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_N));
    shortcutsList->setShortcut(QKeySequence(Qt::Key_F2));

    connect(addAction, &QAction::triggered, this, &MainWindow::createMedia);
    connect(openMediaAction, &QAction::triggered, this, &MainWindow::openMediaFile);
    connect(saveMediaAction, &QAction::triggered, this, &MainWindow::saveMediaFile);
    connect(newMediaFileAction, &QAction::triggered, this, &MainWindow::createNewMediaFile);
    connect(shortcutsList, &QAction::triggered, this, &MainWindow::showShortcuts);

    QLabel* fileLabel = new QLabel(this);
    fileLabel->setText("File: " + (jsonFilePath.isEmpty() ? "Nessuno" : QFileInfo(jsonFilePath).fileName()));
    toolBar->addWidget(fileLabel);

    //QAction* exitAction = new QAction(QIcon(":Images_PAO/exit.png"), "Esci", this);
    toolBar->addWidget(fileToolButton);
    toolBar->addAction(addAction);
    toolBar->addAction(openMediaAction);
    toolBar->addAction(saveMediaAction);
    toolBar->addAction(newMediaFileAction);
    toolBar->addAction(shortcutsList);
    //toolBar->addAction(exitAction);
    

    //connect(exitAction, &QAction::triggered, this, &QMainWindow::close);
}

void MainWindow::displayMediaDetails(Media* media) {
    if (!media) {
        mediaDetails->setText("Seleziona un media per visualizzare i dettagli");
        recensioniButton->setEnabled(false);
        trailerButton->setEnabled(false);
        return;
    }

    currentMedia = media;

    bool isMultimedia = (dynamic_cast<Film*>(media) || dynamic_cast<SerieTV*>(media));
    recensioniButton->setEnabled(isMultimedia);
    trailerButton->setEnabled(isMultimedia);
    QString details = "<html><body>";
    QString imagePath = QString::fromStdString(media->getImagePath());
    if (!imagePath.isEmpty() && QFile::exists(imagePath)) {
        details += QString("<div style='text-align:center;'><img src='%1' width='200' height='300' style='margin-bottom:10px;'></div>")
        .arg(imagePath);
    }

    details += "<h2 style='text-align:center;'>" + QString::fromStdString(media->getTitolo()) + "</h2>";
    details += "<table style='width:100%; border-collapse:collapse;'>";
    details += "<tr><td style='padding:5px; font-weight:bold;'>Tipo:</td><td style='padding:5px;'>" + getMediaType(media) + "</td></tr>";
    details += "<tr><td style='padding:5px; font-weight:bold;'>Anno:</td><td style='padding:5px;'>" + QString::number(media->getAnnoPub()) + "</td></tr>";
    details += "<tr><td><b>Descrizione:  </b></td>"
               "<td><a href='descrizione' "
               "style='text-decoration:none; padding:4px 8px; background:#AB230F; "
               "color:white; border-radius:4px;'>[Mostra]</a></td></tr>";

    details += "</table>";
    details += "<tr><td style='padding:5px; font-weight:bold;'>Genere:</td><td style='padding:5px;'>" + QString::fromStdString(Enums::mediaGenreToString(media->getGenere())) + "</td></tr>";

    mediaDetails->setTextFormat(Qt::RichText);
    mediaDetails->setTextInteractionFlags(Qt::TextBrowserInteraction);
    mediaDetails->setOpenExternalLinks(false); // ci serve per intercettare il click
    mediaDetails->setText(details);

    disconnect(mediaDetails, nullptr, nullptr, nullptr);

    connect(mediaDetails, &QLabel::linkActivated, this, [this, media](const QString& link){
        if (link == "descrizione") {
            QMessageBox::information(this, "Descrizione",
                                     QString::fromStdString(media->getDescrizione()));
        }
    });

    if (Libro* libro = dynamic_cast<Libro*>(media)) {
        details += "<tr><td style='padding:5px; font-weight:bold;'>Autore:</td><td style='padding:5px;'>" + QString::fromStdString(libro->getAutore()) + "</td></tr>";
        details += "<tr><td style='padding:5px; font-weight:bold;'>Editore:</td><td style='padding:5px;'>" + QString::fromStdString(libro->getEditore()) + "</td></tr>";
        details += "<tr><td style='padding:5px; font-weight:bold;'>Pagine:</td><td style='padding:5px;'>" + QString::number(libro->getPagine()) + "</td></tr>";
    }
    else if (Film* film = dynamic_cast<Film*>(media)) {
        details += "<tr><td style='padding:5px; font-weight:bold;'>Regista:</td><td style='padding:5px;'>" + QString::fromStdString(film->getRegista()) + "</td></tr>";
        details += "<tr><td style='padding:5px; font-weight:bold;'>Durata:</td><td style='padding:5px;'>" + QString::number(film->getDurataMinuti()) + " minuti</td></tr>";
    }
    else if (Rivista* rivista = dynamic_cast<Rivista*>(media)) {
        details += "<tr><td style='padding:5px; font-weight:bold;'>Numero:</td><td style='padding:5px;'>" + QString::number(rivista->getNumeroSettimanale()) + "</td></tr>";
        details += "<tr><td style='padding:5px; font-weight:bold;'>Lingua:</td><td style='padding:5px;'>" + QString::fromStdString(Enums::lingueToString(rivista->getLingua())) + "</td></tr>";
    }
    else if (SerieTV* serie = dynamic_cast<SerieTV*>(media)) {
        details += "<tr><td style='padding:5px; font-weight:bold;'>Stagioni:</td><td style='padding:5px;'>" + QString::number(serie->getStagioni()) + "</td></tr>";
        details += "<tr><td style='padding:5px; font-weight:bold;'>In Corso:</td><td style='padding:5px;'>" + QString::fromStdString(serie->getIsInCorso() ? "Sì" : "No") + "</td></tr>";
    }

    mediaDetails->setText(details);
}


void MainWindow::filterMediaList(const QString& searchText)
{
    
    QApplication::setOverrideCursor(Qt::WaitCursor);

    filteredMediaCollection.clear();

    if (searchText.isEmpty()) {
        filteredMediaCollection = mediaCollection;
    } else {
        for (Media* media : mediaCollection) {
            if (mediaMatchesSearch(media, searchText)) {
                filteredMediaCollection.append(media);
            }
        }
    }

    refreshMediaList();
    QApplication::restoreOverrideCursor();
}

bool MainWindow::mediaMatchesSearch(Media* media, const QString& searchText)
{
    QString searchLower = searchText.toLower();

    if (QString::fromStdString(media->getTitolo()).toLower().contains(searchLower)) {
        return true;
    }

    return false;
}

void MainWindow::onSearchRequested(const QString& searchText)
{
    filterMediaList(searchText);
}

void MainWindow::onSearchCleared()
{
    filterMediaList("");
}

void MainWindow::loadMediaFromJson()
{
    if (jsonFilePath.isEmpty()) {
        jsonFilePath = "media_collection.json";
    }

    qDeleteAll(mediaCollection);
    mediaCollection.clear();
    filteredMediaCollection.clear();
    currentMedia = nullptr;

    QList<Media*> loadedMedia = jsonManager->addMediaListFromJson(jsonFilePath);

    if (loadedMedia.isEmpty()) {
        QMessageBox::information(this, "Informazione", "Nessun media trovato o file vuoto");
        return;
    }

    // Aggiungi i media caricati
    mediaCollection = loadedMedia;
    filteredMediaCollection = mediaCollection;

    refreshMediaList();
    updateFileIndicator();

    if (mediaCollection.isEmpty()) {
        QMessageBox::information(this, "Informazione", "Nessun media trovato nel file: " + jsonFilePath);
    } else {
        QMessageBox::information(this, "Successo", QString::number(mediaCollection.size()) + " media caricati con successo!");
    }
}

void MainWindow::saveMediaToJson()
{
    if (jsonFilePath.isEmpty()) {
        QMessageBox::warning(this, "Attenzione", "Nessun file JSON selezionato");
        return;
    }

    QJsonArray jsonArray;
    for (Media* media : mediaCollection) {
        if (dynamic_cast<Libro*>(media)) {
            jsonArray.append(jsonManager->save(static_cast<Libro*>(media)));
        } else if (dynamic_cast<Rivista*>(media)) {
            jsonArray.append(jsonManager->save(static_cast<Rivista*>(media)));
        } else if (dynamic_cast<Film*>(media)) {
            jsonArray.append(jsonManager->save(static_cast<Film*>(media)));
        } else if (dynamic_cast<SerieTV*>(media)) {
            jsonArray.append(jsonManager->save(static_cast<SerieTV*>(media)));
        }
    }

    QFile file(jsonFilePath);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QJsonDocument doc(jsonArray);
        file.write(doc.toJson());
        file.close();
        QMessageBox::information(this, "Successo", "File salvato correttamente: " + jsonFilePath);
    } else {
        QMessageBox::warning(this, "Errore", "Impossibile salvare il file: " + jsonFilePath);
    }
}

QString MainWindow::getMediaType(Media* media)
{
    if (dynamic_cast<Libro*>(media)) return "Libro";
    if (dynamic_cast<Rivista*>(media)) return "Rivista";
    if (dynamic_cast<Film*>(media)) return "Film";
    if (dynamic_cast<SerieTV*>(media)) return "SerieTV";
    return "Media";
}

void MainWindow::refreshMediaList()
{
    clearMediaList();

    // Usa filteredMediaCollection invece di mediaCollection
    for (Media* media : filteredMediaCollection) {
        QListWidgetItem* item = new QListWidgetItem();

        item->setText(QString::fromStdString(media->getTitolo()));

        if (dynamic_cast<Libro*>(media)) {
            item->setIcon(QIcon(":icons/Images_PAO/libro_icon.png"));
        } else if (dynamic_cast<Rivista*>(media)) {
            item->setIcon(QIcon(":icons/Images_PAO/rivista_icon.png"));
        } else if (dynamic_cast<Film*>(media)) {
            item->setIcon(QIcon(":icons/Images_PAO/film_icon.png"));
        } else if (dynamic_cast<SerieTV*>(media)) {
            item->setIcon(QIcon(":icons/Images_PAO/serie_tv_icon.png"));
        }
        item->setData(Qt::UserRole, QVariant::fromValue(static_cast<void*>(media)));

        mediaList->addItem(item);
    }

    if (!searchWidget->getSearchText().isEmpty()) {
        mediaList->addItem(new QListWidgetItem(QString("Trovati %1 risultati").arg(filteredMediaCollection.size())));
    }
}


void MainWindow::showMainScreen()
{
    qDebug() << "Entering showMainScreen()";
    if (stackedWidget && stackedWidget->count() > 1) {
        qDebug() << "Setting current index to 1";
        stackedWidget->setCurrentIndex(1);
    }
    qDebug() << "Exiting showMainScreen()";
}

void MainWindow::onMediaItemClicked(QListWidgetItem* item)
{
    if (!item) return;

    QVariant data = item->data(Qt::UserRole);
    if (data.isValid()) {
        Media* media = static_cast<Media*>(data.value<void*>());
        if (media) {
            displayMediaDetails(media);
        }
    }
}

void MainWindow::onEditButtonClicked()
{
    if (!currentMedia) {
        QMessageBox::warning(this, "Errore", "Nessun media selezionato da modificare.");
        return;
    }

    if (editor) {
        closeEditWindow();
    }

    editor = new EditorMaster(stackedWidget, this);
    stackedWidget->addWidget(editor);
    stackedWidget->setCurrentWidget(editor);

    editor->modifyMedia(currentMedia);

    // Connetti i segnali solo una volta
    connect(editor, &EditorMaster::updateMedia, this, &MainWindow::onMediaUpdated);
    connect(editor, &EditorMaster::modificationCompleted, this, &MainWindow::closeEditWindow);
}
void MainWindow::onDeleteButtonClicked()
{
    QListWidgetItem* currentItem = mediaList->currentItem();
    if (!currentItem) {
        QMessageBox::information(this, "Informazione", "Seleziona un media da eliminare");
        return;
    }

    QVariant data = currentItem->data(Qt::UserRole);
    if (!data.isValid()) {
        QMessageBox::warning(this, "Errore", "Dati del media non validi");
        return;
    }

    Media* media = static_cast<Media*>(data.value<void*>());
    if (!media) {
        QMessageBox::warning(this, "Errore", "Puntatore al media non valido");
        return;
    }

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Conferma eliminazione",
                                  "Sei sicuro di voler eliminare '" + QString::fromStdString(media->getTitolo()) + "'?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        mediaList->takeItem(mediaList->row(currentItem));
        delete currentItem;

        mediaCollection.removeOne(media);
        filteredMediaCollection.removeOne(media);

        delete media;
        saveMediaToJson();

        mediaDetails->setText("Seleziona un media per visualizzare i dettagli");
    }
}


void MainWindow::handleNewMedia(Media* media)
{
    if (!media) {
        QMessageBox::warning(this, "Errore", "Impossibile creare il media: puntatore nullo");
        return;
    }

    mediaCollection.append(media);

    if (searchWidget->getSearchText().isEmpty() ||
        mediaMatchesSearch(media, searchWidget->getSearchText())) {
        filteredMediaCollection.append(media);
    }

    jsonManager->savenewObject(media);
    refreshMediaList();

    QMessageBox::information(this, "Successo", "Media creato con successo: " + QString::fromStdString(media->getTitolo()));
}
void MainWindow::handleMediaUpdate()
{
    if (jsonManager) {
        saveMediaToJson();
        refreshMediaList();

        // Torna alla schermata principale
        if (stackedWidget && stackedWidget->count() > 1) {
            stackedWidget->setCurrentIndex(1);
        }

        // Pulisci l'editor
        if (editor) {
            editor->deleteLater();
            editor = nullptr;
        }
    }
}

void MainWindow::createMedia()
{
    if (editor) {
        qWarning() << "Tentativo di creare un nuovo editor senza che il vecchio sia stato chiuso. Chiusura forzata.";
        closeEditWindow();
    }

    editor = new EditorMaster(stackedWidget, this);
    stackedWidget->addWidget(editor);
    stackedWidget->setCurrentWidget(editor);
    editor->createObject();

    connect(editor, &EditorMaster::newMedia, this, &MainWindow::handleNewMedia);
    connect(editor, &EditorMaster::updateMedia, this, &MainWindow::onMediaUpdated);
    connect(editor, &EditorMaster::modificationCompleted, this, &MainWindow::closeEditWindow);
    connect(editor, &EditorMaster::modificationCanceled, this, &MainWindow::closeEditWindow);
}

bool MainWindow::isValidJsonFile(const QString& filePath) {
    if (filePath.isEmpty()) return false;

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) return false;

    QByteArray data = file.readAll();
    file.close();

    if (data.trimmed().isEmpty()) return true; // File vuoto è valido

    QJsonDocument doc = QJsonDocument::fromJson(data);
    return !doc.isNull() && doc.isArray();
}

void MainWindow::openMediaFile()
{
    QString filePath = QFileDialog::getOpenFileName(this, tr("Apri File Media"), "", tr("JSON Files (*.json)"));
    if (filePath.isEmpty()) return;

    if (!isValidJsonFile(filePath)) {
        QMessageBox::warning(this, "Errore", "Il file selezionato non è un JSON valido.");
        return;
    }

    jsonFilePath = filePath;
    jsonManager->setFilePath(jsonFilePath);

    jsonFilePath = filePath;
    mediaCollection = jsonManager->addMediaListFromJson(jsonFilePath);
    filteredMediaCollection = mediaCollection;
    refreshMediaList();
    updateFileIndicator();
}

void MainWindow::saveMediaFile()
{
    if (jsonFilePath.isEmpty()) {
        QMessageBox::warning(this, "Attenzione", "Nessun file aperto. Usa 'Nuovo file' o 'Apri file' prima.");
        return;
    }

    QString filePath = QFileDialog::getSaveFileName(this, "Save Media File", QDir::homePath(), "JSON Files (*.json)");
    if (!filePath.isEmpty()) {
        jsonFilePath = filePath;
        saveMediaToJson();
        QMessageBox::information(this, "Successo", "File salvato: " + jsonFilePath);
    }

    updateFileIndicator();
}

void MainWindow::createNewMediaFile()
{
    QString filePath = QFileDialog::getSaveFileName(this, "Create New Media File", QDir::homePath(), "JSON Files (*.json)");
    if (!filePath.isEmpty()) {
        jsonFilePath = filePath;
        mediaCollection.clear();
        filteredMediaCollection.clear();

        // Crea un file JSON vuoto
        QFile file(jsonFilePath);
        if (file.open(QIODevice::WriteOnly)) {
            QJsonArray emptyArray;
            QJsonDocument doc(emptyArray);
            file.write(doc.toJson());
            file.close();
        }

        refreshMediaList();
        QMessageBox::information(this, "Successo", "Nuovo file creato: " + jsonFilePath);
    }
    updateFileIndicator();
}

void MainWindow::showShortcuts()
{
    QString shortcutsInfo = 
        "Shortcuts disponibili:\n\n"
        "Ctrl + N: Crea un nuovo media\n"
        "Ctrl + O: Apri un file di media\n"
        "Ctrl + S: Salva il file di media corrente\n"
        "Ctrl + Shift + N: Crea un nuovo file di media\n"
        "F2: Mostra questa lista di shortcuts\n";

    QMessageBox::information(this, "Shortcuts", shortcutsInfo);
}

void MainWindow::closeEditWindow()
{
    if (editor) {
        stackedWidget->removeWidget(editor);
        editor->deleteLater();
        editor = nullptr;
    }
    if (stackedWidget && stackedWidget->count() > 1)
        stackedWidget->setCurrentIndex(1);
}
void MainWindow::editMedia(unsigned int identifier)
{
    for (Media* media : mediaCollection) {
        if (media->getIdentifier() == identifier) {
            editor = new EditorMaster(stackedWidget, this);
            stackedWidget->addWidget(editor);
            stackedWidget->setCurrentWidget(editor);
            editor->modifyMedia(media);
            connect(editor, &EditorMaster::handle, this, &MainWindow::handleMediaUpdate);
            return;
        }
    }
    QMessageBox::warning(this, "Errore", "Media con ID " + QString::number(identifier) + " non trovato.");
}

void MainWindow::getMediaDetails(unsigned int identifier)
{
    for (Media* media : mediaCollection) {
        if (media->getIdentifier() == identifier) {
            displayMediaDetails(media);
            return;
        }
    }
    QMessageBox::warning(this, "Errore", "Media con ID " + QString::number(identifier) + " non trovato.");
}

void MainWindow::addMediaToList(const Media& media)
{
    Media* newMedia = media.clone();
    mediaCollection.append(newMedia);
    filteredMediaCollection.append(newMedia);
    jsonManager->savenewObject(newMedia);
    refreshMediaList();
}

void MainWindow::deleteMedia(unsigned int identifier)
{
    for (int i = 0; i < mediaCollection.size(); ++i) {
        if (mediaCollection[i]->getIdentifier() == identifier) {
            Media* mediaToDelete = mediaCollection[i];

            for (int j = 0; j < mediaList->count(); ++j) {
                QListWidgetItem* item = mediaList->item(j);
                QVariant data = item->data(Qt::UserRole);
                if (data.isValid()) {
                    Media* itemMedia = static_cast<Media*>(data.value<void*>());
                    if (itemMedia && itemMedia->getIdentifier() == identifier) {
                        mediaList->takeItem(j);
                        delete item;
                        break;
                    }
                }
            }

            mediaCollection.removeAt(i);
            filteredMediaCollection.removeOne(mediaToDelete);

            jsonManager->deleteObject(mediaToDelete);
            delete mediaToDelete;

            mediaDetails->setText("Seleziona un media per visualizzare i dettagli");
            return;
        }
    }
    QMessageBox::warning(this, "Errore", "Media con ID " + QString::number(identifier) + " non trovato.");
}

void MainWindow::onDescrizioneButtonClicked()
{
    QListWidgetItem* currentItem = mediaList->currentItem();
    if (!currentItem) {
        QMessageBox::information(this, "Informazione", "Seleziona un media per vedere la descrizione");
        return;
    }

    QVariant data = currentItem->data(Qt::UserRole);
    if (!data.isValid()) {
        QMessageBox::warning(this, "Errore", "Dati del media non validi");
        return;
    }

    Media* media = static_cast<Media*>(data.value<void*>());
    if (!media) {
        QMessageBox::warning(this, "Errore", "Puntatore al media non valido");
        return;
    }

}

void MainWindow::onRecensioniButtonClicked()
{
    if (!currentMedia) return;
    reviewService->fetchRecensioni(currentMedia->getTitolo());
}

void MainWindow::onTrailerButtonClicked()
{
    if (!currentMedia) {
        QMessageBox::warning(this, "Errore", "Nessun media selezionato");
        return;
    }

    QMessageBox::information(this,
                             "Trailer",
                             "Funzionalità non disponibile in questa versione.");
}

void MainWindow::onMediaUpdated(Media* media)
{
    if (media && mediaCollection.contains(media)) {
        saveMediaToJson();
        refreshMediaList();
        displayMediaDetails(media);
    } else {
        // Handle invalid media pointer
        mediaDetails->setText("Seleziona un media per visualizzare i dettagli");
        recensioniButton->setEnabled(false);
        trailerButton->setEnabled(false);
    }
}
