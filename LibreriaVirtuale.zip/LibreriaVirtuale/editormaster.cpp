#include "editormaster.h"

#include "editormaster.h"
#include <QComboBox>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QSpinBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QStackedWidget>
#include <QScrollArea>
#include <QToolBar>
#include <QDebug>
#include "QFileDialog"
#include "QMessageBox"
#include "QCheckBox"
#include "QIcon"

#include "libro.h"
#include "rivista.h"
#include "film.h"
#include "serietv.h"
#include "media.h"
#include "cartaceo.h"
#include "multimedia.h"

EditorMaster::EditorMaster(QStackedWidget* stackWidget, QWidget* parent)
        : QWidget(parent), stack(stackWidget), scrollArea(nullptr), scrollContent(nullptr),
            layout(nullptr), modifyLayout(nullptr), mediaBeingEdited(nullptr)
{
    setWindowTitle("Editor Media");
    resize(600, 400);

    // Layout principale
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(1,1,1,1);

    // Scroll area
    scrollArea = new QScrollArea(this);
    scrollContent = new QWidget(scrollArea);
    layout = new QVBoxLayout(scrollContent);
    scrollArea->setWidget(scrollContent);
    scrollArea->setWidgetResizable(true);
    scrollArea->setStyleSheet("QScrollArea { background-image: url(:/images/bibliotecaV.png); border: none; }");

    QToolBar *toolBar = new QToolBar("Main Toolbar", this);
    QPushButton* close = new QPushButton("Chiudi", scrollContent);
    toolBar->addWidget(close);

    scrollContent->setLayout(layout);
    mainLayout->addWidget(scrollArea);

    modifyLayout = new QVBoxLayout();
    modifyLayout->setContentsMargins(0, 0, 0, 0);
    layout->addLayout(modifyLayout);


connect(close, &QPushButton::clicked, this, &EditorMaster::closeEditor);
}
void EditorMaster::closeEditor(){
    if (stack && stack->count() > 1) {
        stack->setCurrentIndex(1);
    }

    this->deleteLater();
}

void EditorMaster::clearLayout(QLayout* layout) {
    if (layout == nullptr) return;

    while (QLayoutItem* item = layout->takeAt(0)) {
        if (item->widget()) {
            QWidget* widget = item->widget();
            widget->setParent(nullptr); // Rimuovi dal parent
            widget->deleteLater();      // Elimina in modo sicuro
        } else if (item->layout()) {
            clearLayout(item->layout()); // Pulisci ricorsivamente
        }
        delete item; // Elimina l'item
    }
}


void EditorMaster::createObject() {
    QPushButton* crea = new QPushButton(QIcon(":/icons/Images_PAO/save_icon.png"),"Crea Media", this);

    QPushButton* annulla = new QPushButton("Annulla", this); // Aggiungi pulsante annulla
    QHBoxLayout* buttonLayout = new QHBoxLayout(); // Layout orizzontale per i pulsanti

    QStringList mediaTypes = {"Libro", "Rivista", "Film", "Serie TV"};
    QComboBox* mediaTypeCombo = new QComboBox(this);
    mediaTypeCombo->setEditable(true);
    mediaTypeCombo->lineEdit()->setAlignment(Qt::AlignCenter);
    mediaTypeCombo->addItem("Seleziona Tipo Media");
    mediaTypeCombo->addItems(mediaTypes);
    mediaTypeCombo->setCurrentText("Seleziona Tipo Media: ");

    clearLayout(modifyLayout);

    QVBoxLayout* dynamicLayout = new QVBoxLayout();
    layout->addWidget(mediaTypeCombo);

    // Aggiungi i pulsanti in layout orizzontale
    buttonLayout->addWidget(annulla);
    buttonLayout->addWidget(crea);

    layout->addLayout(dynamicLayout);
    layout->addSpacerItem(new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding));
    layout->addLayout(buttonLayout); // Aggiungi il layout dei pulsanti

    connect(mediaTypeCombo, &QComboBox::currentTextChanged, this, [=](const QString& text){
        if(text == "Libro") {
            setupLibro();
        } else if(text == "Rivista") {
            setupRivista();
        } else if(text == "Film") {
            setupFilm();
        } else if(text == "Serie TV") {
            setupSerieTV();
        }
    });

    connect(crea, &QPushButton::clicked, this, [this, mediaTypeCombo](){
        Media* media = nullptr;
        if(mediaTypeCombo->currentText() == "Libro")
            media = createLibro();
        else if(mediaTypeCombo->currentText() == "Rivista")
            media = createRivista();
        else if(mediaTypeCombo->currentText() == "Film")
            media = createFilm();
        else if(mediaTypeCombo->currentText() == "Serie TV")
            media = createSerieTV();
        else
            return;

        if(media){
            emit newMedia(media);
            emit modificationCompleted(); // Chiudi l'editor dopo la creazione
        }
    });

    // Connessione per il pulsante Annulla
    connect(annulla, &QPushButton::clicked, this, &EditorMaster::annulla);
}

void EditorMaster::modifyMedia(Media* media) {
    if (!media) return;
    clearLayout(modifyLayout);
    mediaBeingEdited = media;

    setupMedia(media);

    if (auto cartaceo = dynamic_cast<Cartaceo*>(media)) {
        setupCartaceo(cartaceo);
    }
    if (auto libro = dynamic_cast<Libro*>(media)) {
        setupLibro(libro);
    }
    if (auto rivista = dynamic_cast<Rivista*>(media)) {
        setupRivista(rivista);
    }
    if (auto multimedia = dynamic_cast<Multimedia*>(media)) {
        setupMultimedia(multimedia);
    }
    if (auto film = dynamic_cast<Film*>(media)) {
        setupFilm(film);
    }
    if (auto serie = dynamic_cast<SerieTV*>(media)) {
        setupSerieTV(serie);
    }

    QPushButton* conferma = new QPushButton("Conferma", this);
    conferma->setIcon(QIcon(":/icons/Images_PAO/save_icon.png"));

    QPushButton* annullaBtn = new QPushButton("Annulla", this);

    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->setAlignment(Qt::AlignRight);
    buttonLayout->addWidget(annullaBtn);
    buttonLayout->addWidget(conferma);


    modifyLayout->addStretch();
    modifyLayout->addLayout(buttonLayout);

    connect(conferma, &QPushButton::clicked, this, [this, media]() {
        save(const_cast<Media*>(media));

        if (auto libro = dynamic_cast<Libro*>(const_cast<Media*>(media))) {
            saveLibro(libro);
        } else if (auto rivista = dynamic_cast<Rivista*>(const_cast<Media*>(media))) {
            saveRivista(rivista);
        } else if (auto film = dynamic_cast<Film*>(const_cast<Media*>(media))) {
            saveFilm(film);
        } else if (auto serie = dynamic_cast<SerieTV*>(const_cast<Media*>(media))) {
            saveSerieTV(serie);
        }

        emit updateMedia(const_cast<Media*>(media));
        emit modificationCompleted();

        QMessageBox::information(this, "Modifica completata",
                                 "Le modifiche sono state salvate con successo.");

        closeEditor();
    });

    connect(annullaBtn, &QPushButton::clicked, this, &EditorMaster::annulla);

        stack->setCurrentWidget(scrollArea);
}

void EditorMaster::salvaModifiche()
{
    if (!mediaBeingEdited) return;

    if (stack && stack->count() > 1) {
        stack->setCurrentIndex(1);
    }
    this->deleteLater();
}


void EditorMaster::annulla() {
    emit modificationCanceled();
    this->deleteLater();
}


void EditorMaster::setupMedia(Media* media) {
    image = "";

    clearLayout(modifyLayout);
    menuWidgets.clear();
    QLabel* identifier = new QLabel(scrollContent);
    identifier->setText("Identifier:");
    QSpinBox* identifierMenu = new QSpinBox(scrollContent);
    identifierMenu->setRange(1, 1000000);
    identifierMenu->setValue(media ? media->getIdentifier() : 1);


    modifyLayout->addWidget(identifier);
    modifyLayout->addWidget(identifierMenu);
    menuWidgets["identifier"] = identifierMenu;

    QLabel* titolo = new QLabel(scrollContent);
    titolo->setText("Titolo:");
    QLineEdit* titoloMenu = new QLineEdit(scrollContent);
    titoloMenu->setPlaceholderText("Inserisci il titolo del media");
    titoloMenu->setText(media ? QString::fromStdString(media->getTitolo()) : "");
    menuWidgets["titolo"] = titoloMenu;
    modifyLayout->addWidget(titolo);
    modifyLayout->addWidget(titoloMenu);

    QLabel* annoPub = new QLabel(scrollContent);
    annoPub->setText("Anno di Pubblicazione:");
    QSpinBox* annoPubMenu = new QSpinBox(scrollContent);
    annoPubMenu->setRange(1800, 2100);
    annoPubMenu->setValue(media ? media->getAnnoPub() : 2024);
    menuWidgets["annoPub"] = annoPubMenu;
    modifyLayout->addWidget(annoPub);
    modifyLayout->addWidget(annoPubMenu);

    QLabel* descrizione = new QLabel(scrollContent);
    descrizione->setText("Descrizione:");
    QLineEdit* descrizioneMenu = new QLineEdit(scrollContent);
    descrizioneMenu->setPlaceholderText("Inserisci la descrizione del media");
    descrizioneMenu->setText(media ? QString::fromStdString(media->getDescrizione()) : "");
    menuWidgets["descrizione"] = descrizioneMenu;
    modifyLayout->addWidget(descrizione);
    modifyLayout->addWidget(descrizioneMenu);

    QLabel* genere = new QLabel(scrollContent);
    genere->setText("Genere:");
    QComboBox* genereMenu = new QComboBox(scrollContent);
    QStringList generi = {"Fantascienza", "Fantasy", "Horror", "Commedia", "Drammatico", "Documentario",
                          "Thriller", "Romantico", "Avventura", "Animazione", "Storico", "Biografico",
                          "Musicale", "Guerra", "Western"};
    genereMenu->addItems(generi);
    if(media) {
        genereMenu->setCurrentIndex(static_cast<int>(media->getGenere()));
    } else {
        genereMenu->setCurrentIndex(0);
    }
    menuWidgets["genere"] = genereMenu;
    modifyLayout->addWidget(genere);
    modifyLayout->addWidget(genereMenu);

    QLabel* image_path = new QLabel(scrollContent);
    image_path->setText("Percorso Immagine:");
    QLineEdit* image_pathMenu = new QLineEdit(scrollContent);
    image_pathMenu->setPlaceholderText("Inserisci il percorso dell'immagine");
    image_pathMenu->setText(media ? QString::fromStdString(media->getImagePath()) : "");
    menuWidgets["image_path"] = image_pathMenu;
    modifyLayout->addWidget(image_path);
    modifyLayout->addWidget(image_pathMenu);

    QPushButton* selectImageButton = new QPushButton("Seleziona File", scrollContent);
    connect(selectImageButton, &QPushButton::clicked, this, [this, image_pathMenu]() {
        QString filePath = QFileDialog::getOpenFileName(this, "Seleziona Immagine", "", "Image Files (*.png *.jpg);;All Files (*)");
        if (!filePath.isEmpty()) {
            image_pathMenu->setText(filePath);
        }
    });
    modifyLayout->addWidget(selectImageButton);

}

void EditorMaster::setupCartaceo(Cartaceo* cartaceo) {
    setupMedia(static_cast<Media*>(cartaceo));
    
    QLabel* pagine = new QLabel(scrollContent);
    pagine->setText("Numero di Pagine:");
    QSpinBox* pagineMenu = new QSpinBox(scrollContent);
    pagineMenu->setRange(1, 10000);
    pagineMenu->setValue(cartaceo ? cartaceo->getPagine() : 1);
    menuWidgets["pagine"] = pagineMenu;
    modifyLayout->addWidget(pagine);
    modifyLayout->addWidget(pagineMenu);

    QLabel* editore = new QLabel(scrollContent);
    editore->setText("Editore:");
    QLineEdit* editoreMenu = new QLineEdit(scrollContent);
    editoreMenu->setPlaceholderText("Inserisci il nome dell'editore");
    editoreMenu->setText(cartaceo ? QString::fromStdString(cartaceo->getEditore()) : "");
    menuWidgets["editore"] = editoreMenu;
    modifyLayout->addWidget(editore);
    modifyLayout->addWidget(editoreMenu);

    QLabel* autore = new QLabel(scrollContent);
    autore->setText("Autore:");
    QLineEdit* autoreMenu = new QLineEdit(scrollContent);
    autoreMenu->setPlaceholderText("Inserisci il nome dell'autore");
    autoreMenu->setText(cartaceo ? QString::fromStdString(cartaceo->getAutore()) : "");
    menuWidgets["autore"] = autoreMenu;
    modifyLayout->addWidget(autore);
    modifyLayout->addWidget(autoreMenu);

}

void EditorMaster::setupMultimedia(Multimedia* multimedia){
    setupMedia(static_cast<Media*>(multimedia));

    QLabel* regista = new QLabel(scrollContent);
    regista->setText("Regista:");
    QLineEdit* registaMenu = new QLineEdit(scrollContent);
    registaMenu->setPlaceholderText("Inserisci il nome del regista");
    registaMenu->setText(multimedia ? QString::fromStdString(multimedia->getRegista()) : "");
    menuWidgets["regista"] = registaMenu;
    modifyLayout->addWidget(regista);
    modifyLayout->addWidget(registaMenu);

    QLabel* studioProduzione = new QLabel(scrollContent);
    studioProduzione->setText("Studio di Produzione:");
    QLineEdit* studioProduzioneMenu = new QLineEdit(scrollContent);
    studioProduzioneMenu->setPlaceholderText("Inserisci il nome dello studio di produzione");
    studioProduzioneMenu->setText(multimedia ? QString::fromStdString(multimedia->getStudioProduzione()) : "");
    menuWidgets["studioProduzione"] = studioProduzioneMenu;
    modifyLayout->addWidget(studioProduzione);
    modifyLayout->addWidget(studioProduzioneMenu);

    // Aggiungi AgeRating ComboBox
    QLabel* ageRatingLabel = new QLabel(scrollContent);
    ageRatingLabel->setText("Age Rating:");
    QComboBox* ageRatingMenu = new QComboBox(scrollContent);
    QStringList ageRatings = {"G", "PG", "PG13", "R", "NC17"};
    ageRatingMenu->addItems(ageRatings);
    if (multimedia) {
        ageRatingMenu->setCurrentIndex(static_cast<int>(multimedia->getAgeRating()));
    } else {
        ageRatingMenu->setCurrentIndex(0);
    }
    menuWidgets["ageRating"] = ageRatingMenu;
    modifyLayout->addWidget(ageRatingLabel);
    modifyLayout->addWidget(ageRatingMenu);

    QLabel* media_pathing = new QLabel(scrollContent);
    media_pathing->setText("Percorso Media:");
    QLineEdit* media_pathMenu = new QLineEdit(scrollContent);
    media_pathMenu->setPlaceholderText("Inserisci il percorso del media");
    media_pathMenu->setText(multimedia ? QString::fromStdString(multimedia->getMediaPath()) : "");
    menuWidgets["media_path"] = media_pathMenu;
    modifyLayout->addWidget(media_pathing);
    modifyLayout->addWidget(media_pathMenu);

    // Bottone per selezionare file (solo per i file, non per i trailer)
    QPushButton* selectMediaButton = new QPushButton("Seleziona File Media", scrollContent);
    connect(selectMediaButton, &QPushButton::clicked, this, [this, media_pathMenu]() {
        QString filePath = QFileDialog::getOpenFileName(this, "Seleziona File Multimediale", "",
                                                        "Video Files (*.mp4 *.avi *.mkv);;All Files (*)");
        if (!filePath.isEmpty()) {
            media_pathMenu->setText(filePath);
        }
    });
    modifyLayout->addWidget(selectMediaButton);
}

void EditorMaster::setupFilm(Film* film) {
    setupMultimedia(static_cast<Multimedia*>(film));

    QLabel* durata = new QLabel(scrollContent);
    durata->setText("Durata (minuti):");
    QSpinBox* durataMenu = new QSpinBox(scrollContent);
    durataMenu->setRange(1, 500);
    durataMenu->setValue(film ? film->getDurataMinuti() : 90);
    menuWidgets["durata"] = durataMenu;
    modifyLayout->addWidget(durata);
    modifyLayout->addWidget(durataMenu);

    QLabel* qualitaVideo = new QLabel(scrollContent);
    qualitaVideo->setText("Qualità Video:");
    QComboBox* qualitaVideoMenu = new QComboBox(scrollContent);
    QStringList qualitaOptions = {"SD", "HD", "FHD", "UHD", "HDR"};
    qualitaVideoMenu->addItems(qualitaOptions);
    if (film) {
        qualitaVideoMenu->setCurrentIndex(static_cast<int>(film->getQualitaVideo()));
        } else {
            qualitaVideoMenu->setCurrentIndex(0);
        }
        menuWidgets["qualitaVideo"] = qualitaVideoMenu; // Aggiungi al menuWidgets
        modifyLayout->addWidget(qualitaVideo);
        modifyLayout->addWidget(qualitaVideoMenu);
    }

void EditorMaster::setupSerieTV(SerieTV* serieTV) {
    setupMultimedia(static_cast<Multimedia*>(serieTV));

    QLabel* stagioni = new QLabel(scrollContent);
    stagioni->setText("Numero di Stagioni:");
    QSpinBox* stagioniMenu = new QSpinBox(scrollContent);
    stagioniMenu->setRange(1, 100);
    stagioniMenu->setValue(serieTV ? serieTV->getStagioni() : 1);
    menuWidgets["stagioni"] = stagioniMenu;
    modifyLayout->addWidget(stagioni);
    modifyLayout->addWidget(stagioniMenu);

    QLabel* IsInCorso = new QLabel(scrollContent);
    IsInCorso->setText("In corso?:");
    QCheckBox* InCorso = new QCheckBox(scrollContent);
    InCorso->setChecked(serieTV ? serieTV->getIsInCorso() : false);
    menuWidgets["isInCorso"] = InCorso;
    modifyLayout->addWidget(IsInCorso);
    modifyLayout->addWidget(InCorso);

}

void EditorMaster::setupLibro(Libro* libro) {
    setupCartaceo(static_cast<Cartaceo*>(libro));
    
    QLabel* isbn = new QLabel(scrollContent);
    isbn->setText("ISBN:");
    QLineEdit* isbnMenu = new QLineEdit(scrollContent);
    isbnMenu->setPlaceholderText("Inserisci il codice ISBN");
    isbnMenu->setText(libro ? QString::fromStdString(libro->getISBN()) : "");
    menuWidgets["ISBN"] = isbnMenu;
    modifyLayout->addWidget(isbn);
    modifyLayout->addWidget(isbnMenu);

    QLabel* lingua = new QLabel(scrollContent);
    lingua->setText("Lingua:");
    QComboBox* linguaMenu = new QComboBox(scrollContent);
    QStringList lingue = {"Italiano", "Inglese", "Spagnolo", "Francese", "Tedesco", "Cinese",
                          "Giapponese", "Russo", "Arabo", "Portoghese", "Altro"};
    linguaMenu->addItems(lingue);
    if(libro) {
        linguaMenu->setCurrentIndex(static_cast<int>(libro->getLingua()));
    } else {
        linguaMenu->setCurrentIndex(0);
    }
    menuWidgets["lingua"] = linguaMenu;
    modifyLayout->addWidget(lingua);
    modifyLayout->addWidget(linguaMenu);
}

void EditorMaster::setupRivista(Rivista* rivista) {
    setupCartaceo(static_cast<Cartaceo*>(rivista));

    QLabel* lingua = new QLabel(scrollContent);
    lingua->setText("Lingua:");
    QComboBox* linguaMenu = new QComboBox(scrollContent);
    QStringList lingue = {"Italiano", "Inglese", "Spagnolo", "Francese", "Tedesco", "Cinese",
                          "Giapponese", "Russo", "Arabo", "Portoghese", "Altro"};
    linguaMenu->addItems(lingue);
    if(rivista) {
        linguaMenu->setCurrentIndex(static_cast<int>(rivista->getLingua()));
    } else {
        linguaMenu->setCurrentIndex(0);
    }
    menuWidgets["lingua"] = linguaMenu;
    modifyLayout->addWidget(lingua);
    modifyLayout->addWidget(linguaMenu);

    QLabel* numeroSettimanale = new QLabel(scrollContent);
    numeroSettimanale->setText("Numero Settimanale:");
    QSpinBox* numeroSettimanaleMenu = new QSpinBox(scrollContent);
    numeroSettimanaleMenu->setRange(1, 52);
    numeroSettimanaleMenu->setValue(rivista ? rivista->getNumeroSettimanale() : 1);
    menuWidgets["numeroSettimanale"] = numeroSettimanaleMenu;
    modifyLayout->addWidget(numeroSettimanale);
    modifyLayout->addWidget(numeroSettimanaleMenu);

}

void EditorMaster::save(Media* media) {
    if (!media) return;

    QLineEdit* titoloEdit = qobject_cast<QLineEdit*>(menuWidgets.value("titolo"));
    if (titoloEdit) {
        QString titolo = titoloEdit->text();
        media->setTitolo(titolo.toStdString());
    }
    QString titolo = (qobject_cast<QLineEdit*>(menuWidgets["titolo"]))->text();
    media->setTitolo(titolo.toStdString());
    int annoPub = (qobject_cast<QSpinBox*>(menuWidgets["annoPub"]))->value();
    media->setAnnoPub(annoPub);
    QString descrizione = (qobject_cast<QLineEdit*>(menuWidgets["descrizione"]))->text();
    media->setDescrizione(descrizione.toStdString());
    Enums::MediaGenre genere = static_cast<Enums::MediaGenre>((qobject_cast<QComboBox*>(menuWidgets["genere"]))->currentIndex());
    media->setGenere(genere);
    QString image_path = (qobject_cast<QLineEdit*>(menuWidgets["image_path"]))->text();
    media->setImagePath(image_path.toStdString());
}

void EditorMaster::saveCartaceo(Cartaceo* cartaceo) {
    save(static_cast<Media*>(cartaceo));
    int pagine = (qobject_cast<QSpinBox*>(menuWidgets["pagine"]))->value();
    cartaceo->setPagine(pagine);
    QString editore = (qobject_cast<QLineEdit*>(menuWidgets["editore"]))->text();
    cartaceo->setEditore(editore.toStdString());
    QString autore = (qobject_cast<QLineEdit*>(menuWidgets["autore"]))->text();
    cartaceo->setAutore(autore.toStdString());
}

void EditorMaster::saveMultimedia(Multimedia* multimedia) {
    save(static_cast<Media*>(multimedia));
    QString regista = (qobject_cast<QLineEdit*>(menuWidgets["regista"]))->text();
    multimedia->setRegista(regista.toStdString());
    QString studioProduzione = (qobject_cast<QLineEdit*>(menuWidgets["studioProduzione"]))->text();
    multimedia->setStudioProduzione(studioProduzione.toStdString());
    QString media_path = (qobject_cast<QLineEdit*>(menuWidgets["media_path"]))->text();
    multimedia->setMediaPath(media_path.toStdString());
}

void EditorMaster::saveLibro(Libro* libro) {
    saveCartaceo(static_cast<Cartaceo*>(libro));
    QString isbn = (qobject_cast<QLineEdit*>(menuWidgets["ISBN"]))->text();
    libro->setISBN(isbn.toStdString());
    Enums::Lingue lingua = static_cast<Enums::Lingue>((qobject_cast<QComboBox*>(menuWidgets["lingua"]))->currentIndex());
    libro->setLingua(lingua);
}

void EditorMaster::saveRivista(Rivista* rivista) {
    saveCartaceo(static_cast<Cartaceo*>(rivista));
    Enums::Lingue lingua = static_cast<Enums::Lingue>((qobject_cast<QComboBox*>(menuWidgets["lingua"]))->currentIndex());
    rivista->setLingua(lingua);
    int numeroSettimanale = (qobject_cast<QSpinBox*>(menuWidgets["numeroSettimanale"]))->value();
    rivista->setNumeroSettimanale(numeroSettimanale);
}

void EditorMaster::saveFilm(Film* film) {
    saveMultimedia(static_cast<Multimedia*>(film));
    int durata = (qobject_cast<QSpinBox*>(menuWidgets["durata"]))->value();
    film->setDurataMinuti(durata);
    // La qualità video non è memorizzata nell'oggetto Film, quindi non la salviamo
}

void EditorMaster::saveSerieTV(SerieTV* serieTV) {
    saveMultimedia(static_cast<Multimedia*>(serieTV));
    int stagioni = (qobject_cast<QSpinBox*>(menuWidgets["stagioni"]))->value();
    serieTV->setStagioni(stagioni);
    bool isInCorso = (qobject_cast<QCheckBox*>(menuWidgets["isInCorso"]))->isChecked();
    serieTV->setIsInCorso(isInCorso);
}

EditorMaster::MediaInfo EditorMaster::createMedia() {
    MediaInfo info;
    info.identifier = (qobject_cast<QSpinBox*>(menuWidgets["identifier"]))->value();
    info.titolo = (qobject_cast<QLineEdit*>(menuWidgets["titolo"]))->text();
    info.AnnoPub = (qobject_cast<QSpinBox*>(menuWidgets["annoPub"]))->value();
    info.descrizione = (qobject_cast<QLineEdit*>(menuWidgets["descrizione"]))->text();
    info.genere = static_cast<Enums::MediaGenre>((qobject_cast<QComboBox*>(menuWidgets["genere"]))->currentIndex());
    info.image_path = (qobject_cast<QLineEdit*>(menuWidgets["image_path"]))->text();
    return info;
}

EditorMaster::CartaceoInfo EditorMaster::createCartaceo() {
    CartaceoInfo info;
    info.pagine = (qobject_cast<QSpinBox*>(menuWidgets["pagine"]))->value();
    info.editore = (qobject_cast<QLineEdit*>(menuWidgets["editore"]))->text();
    info.autore = (qobject_cast<QLineEdit*>(menuWidgets["autore"]))->text();
    return info;
}

EditorMaster::MultimediaInfo EditorMaster::createMultimedia() {
    MultimediaInfo info;
    info.regista = (qobject_cast<QLineEdit*>(menuWidgets["regista"]))->text();
    info.studioProduzione = (qobject_cast<QLineEdit*>(menuWidgets["studioProduzione"]))->text();
    info.media_path = (qobject_cast<QLineEdit*>(menuWidgets["media_path"]))->text();
    info.AgeRating = static_cast<Enums::AgeRating>((qobject_cast<QComboBox*>(menuWidgets["ageRating"]))->currentIndex());
    return info;
}

Libro* EditorMaster::createLibro() {
    MediaInfo mediaInfo = createMedia();
    CartaceoInfo cartaceoInfo = createCartaceo();
    QString isbn = (qobject_cast<QLineEdit*>(menuWidgets["ISBN"]))->text();
    Enums::Lingue lingua = static_cast<Enums::Lingue>((qobject_cast<QComboBox*>(menuWidgets["lingua"]))->currentIndex());
    return new Libro(mediaInfo.identifier, mediaInfo.titolo.toStdString(), mediaInfo.AnnoPub,
                     mediaInfo.descrizione.toStdString(), mediaInfo.genere,
                     mediaInfo.image_path.toStdString(), cartaceoInfo.pagine,
                     cartaceoInfo.autore.toStdString(), cartaceoInfo.editore.toStdString(),
                     isbn.toStdString(), lingua);
}

Rivista* EditorMaster::createRivista() {
    MediaInfo mediaInfo = createMedia();
    CartaceoInfo cartaceoInfo = createCartaceo();
    Enums::Lingue lingua = static_cast<Enums::Lingue>((qobject_cast<QComboBox*>(menuWidgets["lingua"]))->currentIndex());
    int numeroSettimanale = (qobject_cast<QSpinBox*>(menuWidgets["numeroSettimanale"]))->value();

    return new Rivista(mediaInfo.identifier, mediaInfo.titolo.toStdString(), mediaInfo.AnnoPub,
                       mediaInfo.descrizione.toStdString(), mediaInfo.genere,
                       mediaInfo.image_path.toStdString(), cartaceoInfo.pagine,
                       cartaceoInfo.editore.toStdString(), cartaceoInfo.autore.toStdString(),
                       lingua, numeroSettimanale);
}

SerieTV* EditorMaster::createSerieTV() {
    MediaInfo mediaInfo = createMedia();
    MultimediaInfo multimediaInfo = createMultimedia();
    int stagioni = (qobject_cast<QSpinBox*>(menuWidgets["stagioni"]))->value();
    bool isInCorso = (qobject_cast<QCheckBox*>(menuWidgets["isInCorso"]))->isChecked();

    return new SerieTV(mediaInfo.identifier, mediaInfo.titolo.toStdString(), mediaInfo.AnnoPub,
                       mediaInfo.descrizione.toStdString(), mediaInfo.genere,
                       mediaInfo.image_path.toStdString(), multimediaInfo.regista.toStdString(),
                       multimediaInfo.studioProduzione.toStdString(), multimediaInfo.media_path.toStdString(),
                       multimediaInfo.AgeRating, stagioni, isInCorso);
}

Film* EditorMaster::createFilm() {
    MediaInfo mediaInfo = createMedia();
    MultimediaInfo multimediaInfo = createMultimedia();
    int durata = (qobject_cast<QSpinBox*>(menuWidgets["durata"]))->value();
    Enums::VideoQuality qualitaVideo = static_cast<Enums::VideoQuality>((qobject_cast<QComboBox*>(menuWidgets["qualitaVideo"]))->currentIndex());

    return new Film(mediaInfo.identifier, mediaInfo.titolo.toStdString(), mediaInfo.AnnoPub,
                    mediaInfo.descrizione.toStdString(), mediaInfo.genere,
                    mediaInfo.image_path.toStdString(), multimediaInfo.regista.toStdString(),
                    multimediaInfo.studioProduzione.toStdString(), multimediaInfo.media_path.toStdString(),
                    multimediaInfo.AgeRating, durata, qualitaVideo);
}
