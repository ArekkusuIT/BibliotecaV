#ifndef FULLMEDIA_H
#define FULLMEDIA_H

#include <QWidget>
#include <QLabel>
#include <QPixmap>
#include <QPushButton>
#include "QVBoxLayout"
#include <vector>

#include "media.h"
#include "bconstvisitor.h"
#include "recensioni.h"


class FullMedia: public QWidget, public virtual BConstVisitor
{
    Q_OBJECT
private:
    QVBoxLayout* mainLayout;
    QHBoxLayout* buttonLayout;
    QVBoxLayout* detailsLayout;
    QLabel* titoloLabel;
    QLabel* identifierLabel;
    QPushButton* editButton;
    QPushButton* deleteButton;

    unsigned int ID;

    void clearLayout(QLayout* layout);
    void onClickedEditButton();
    void onClickedDeleteButton();

public:

    explicit FullMedia(QWidget* parent = nullptr);
    virtual void visit(const Libro& libro);
    virtual void visit(const Rivista& rivista);
    virtual void visit(const Film& film);
    virtual void visit(const SerieTV& serieTV);

public slots:
    void displayInfo(const Media& media);
    void onRecensioniButtonClicked(const std::string& titolo);

signals:
    void showEditWindow(unsigned int identifier);
    void deleteMedia(unsigned int identifier);
    void showRecensioni(const std::vector<Recensioni>& recensioni);
};

#endif // FULLMEDIA_H
