/****************************************************************************
** Meta object code from reading C++ file 'editormaster.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../editormaster.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'editormaster.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_EditorMaster_t {
    const uint offsetsAndSize[28];
    char stringdata0[158];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_EditorMaster_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_EditorMaster_t qt_meta_stringdata_EditorMaster = {
    {
QT_MOC_LITERAL(0, 12), // "EditorMaster"
QT_MOC_LITERAL(13, 8), // "newMedia"
QT_MOC_LITERAL(22, 0), // ""
QT_MOC_LITERAL(23, 6), // "Media*"
QT_MOC_LITERAL(30, 5), // "media"
QT_MOC_LITERAL(36, 11), // "updateMedia"
QT_MOC_LITERAL(48, 6), // "handle"
QT_MOC_LITERAL(55, 21), // "modificationCompleted"
QT_MOC_LITERAL(77, 20), // "modificationCanceled"
QT_MOC_LITERAL(98, 7), // "annulla"
QT_MOC_LITERAL(106, 11), // "closeEditor"
QT_MOC_LITERAL(118, 14), // "salvaModifiche"
QT_MOC_LITERAL(133, 11), // "modifyMedia"
QT_MOC_LITERAL(145, 12) // "createObject"

    },
    "EditorMaster\0newMedia\0\0Media*\0media\0"
    "updateMedia\0handle\0modificationCompleted\0"
    "modificationCanceled\0annulla\0closeEditor\0"
    "salvaModifiche\0modifyMedia\0createObject"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EditorMaster[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   74,    2, 0x06,    1 /* Public */,
       5,    1,   77,    2, 0x06,    3 /* Public */,
       6,    0,   80,    2, 0x06,    5 /* Public */,
       7,    0,   81,    2, 0x06,    6 /* Public */,
       8,    0,   82,    2, 0x06,    7 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       9,    0,   83,    2, 0x08,    8 /* Private */,
      10,    0,   84,    2, 0x08,    9 /* Private */,
      11,    0,   85,    2, 0x08,   10 /* Private */,
      12,    1,   86,    2, 0x0a,   11 /* Public */,
      13,    0,   89,    2, 0x0a,   13 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,

       0        // eod
};

void EditorMaster::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<EditorMaster *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->newMedia((*reinterpret_cast< std::add_pointer_t<Media*>>(_a[1]))); break;
        case 1: _t->updateMedia((*reinterpret_cast< std::add_pointer_t<Media*>>(_a[1]))); break;
        case 2: _t->handle(); break;
        case 3: _t->modificationCompleted(); break;
        case 4: _t->modificationCanceled(); break;
        case 5: _t->annulla(); break;
        case 6: _t->closeEditor(); break;
        case 7: _t->salvaModifiche(); break;
        case 8: _t->modifyMedia((*reinterpret_cast< std::add_pointer_t<Media*>>(_a[1]))); break;
        case 9: _t->createObject(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (EditorMaster::*)(Media * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EditorMaster::newMedia)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (EditorMaster::*)(Media * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EditorMaster::updateMedia)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (EditorMaster::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EditorMaster::handle)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (EditorMaster::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EditorMaster::modificationCompleted)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (EditorMaster::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EditorMaster::modificationCanceled)) {
                *result = 4;
                return;
            }
        }
    }
}

const QMetaObject EditorMaster::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_EditorMaster.offsetsAndSize,
    qt_meta_data_EditorMaster,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_EditorMaster_t
, QtPrivate::TypeAndForceComplete<EditorMaster, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Media *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Media *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Media *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *EditorMaster::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EditorMaster::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_EditorMaster.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int EditorMaster::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void EditorMaster::newMedia(Media * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void EditorMaster::updateMedia(Media * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void EditorMaster::handle()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void EditorMaster::modificationCompleted()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void EditorMaster::modificationCanceled()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
