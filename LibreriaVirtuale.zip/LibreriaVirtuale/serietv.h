#ifndef SERIETV_H
#define SERIETV_H

#include "multimedia.h"
#include "Enums/mediaenums.h"
#include "string"

class SerieTV: public Multimedia
{
private:
    int stagioni;
    bool isInCorso;
public:
    SerieTV(const unsigned int identifier,
            std::string titolo,
            int AnnoPub,
            std::string descrizione,
            Enums::MediaGenre genere,
            std::string image_path,
            std::string regista,
            std::string studioProduzione,
            std::string media_path,
            Enums::AgeRating AgeRating,
            int stagioni,
            bool isInCorso = false);

    Media* clone() const;

    int getStagioni() const;
    SerieTV& setStagioni(const int stagioni);
    bool getIsInCorso() const;
    SerieTV& setIsInCorso(const bool isInCorso);
    virtual void accept(class BVisitor& v);
    virtual void accept(class BConstVisitor& v) const;
};

#endif // SERIETV_H
