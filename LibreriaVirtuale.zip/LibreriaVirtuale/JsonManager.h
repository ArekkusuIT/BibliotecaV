#ifndef JSONMANAGER_H
#define JSONMANAGER_H

#include <map>
#include <string>
#include <vector>
#include "media.h"

#include <QObject>
#include <QString>
#include <QJsonObject>
#include "cartaceo.h"
#include "multimedia.h"

class JsonManager : public QObject {
    Q_OBJECT

private:
    QList<Media*> repository;
    QString filePath;
public:
    JsonManager(const QString& fileName);


    struct MediaBase {
        int identifier;
        QString titolo;
        int AnnoPub;
        QString descrizione;
        Enums::MediaGenre genere;
        QString image_path;
    };
    struct CartaceoBase{
        int pagine;
        QString autore;
        QString editore;
    };
    struct MultimediaBase{
        QString regista;
        QString studioProduzione;
        QString media_path;
        Enums::AgeRating AgeRating;
    };
public slots:
    void deleteObject(Media* media);
    void savenewObject(Media* media);
    void updateObject(Media* media);
    void debugJsonStructure();
public:
    void setFilePath(const QString& path);
    QString getFilePath() const { return filePath; }
    QList<Media*> addMediaListFromJson(const QString& filename);
    void setOggetti(const QList<Media*>& newMedia);
    Media* loadRivista(const QJsonObject& obj);
    Media* loadFilm(const QJsonObject& obj);
    Media* loadSerieTV(const QJsonObject& obj);
    Media* loadLibro(const QJsonObject& obj);
    MediaBase loadMedia(const QJsonObject& jsonObj);
    CartaceoBase loadCartaceo(const QJsonObject& jsonObj);
    MultimediaBase loadMultimedia(const QJsonObject& jsonObj);
    void save(Media* media, QJsonObject& jsonObj);
    void save(Cartaceo* cartaceo, QJsonObject& jsonObj);
    void save(Multimedia* multimedia, QJsonObject& jsonObj);
    QJsonObject save(Libro* libro);
    QJsonObject save(Rivista* rivista);
    QJsonObject save(Film* film);
    QJsonObject save(SerieTV* serieTV);
};

#endif // JSONMANAGER_H
