#include "JsonManager.h"
#include <QStringList>
#include <QMap>
#include <QFile>
#include <QJsonArray>
#include <QByteArray>
#include <QList>
#include <QJsonDocument>
#include <QFileInfo>

#include "libro.h"
#include "rivista.h"
#include "film.h"
#include "serietv.h"
#include "Enums/enumsconversion.h"


JsonManager::JsonManager(const QString& fileName)
    : filePath(fileName) {}

void JsonManager::setFilePath(const QString& path) {
    filePath = path;
}

void JsonManager::setOggetti(const QList<Media*>& newMedia) {
    qDeleteAll(repository);
    repository.clear();

    for (Media* media : newMedia) {
        if (media) {
            repository.append(media);
        }
    }

}

QList<Media*> JsonManager::addMediaListFromJson(const QString& filename) {
    QList<Media*> mediaList;
    QFile file(filename);

    if (!file.exists()) {
        qWarning() << "Il file non esiste:" << filename;
        if (file.open(QIODevice::WriteOnly)) {
            QJsonArray emptyArray;
            QJsonDocument doc(emptyArray);
            file.write(doc.toJson());
            file.close();
        }
        return mediaList;
    }

    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Impossibile aprire il file:" << filename;
        return mediaList;
    }

    QByteArray data = file.readAll();
    file.close();

    if (data.trimmed().isEmpty()) {
        qWarning() << "Il file JSON è vuoto:" << filename;
        return mediaList;
    }

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (doc.isNull() || !doc.isArray()) {
        qWarning() << "Il file JSON non contiene un array valido o è corrotto:" << filename;
        return mediaList;
    }

    QJsonArray jsonArray = doc.array();
    for (const QJsonValue& value : jsonArray) {
        if (value.isObject()) {
            QJsonObject jsonObj = value.toObject();

            // Controlla se l'oggetto ha il campo "Tipo"
            if (!jsonObj.contains("Tipo")) {
                qWarning() << "Oggetto JSON senza campo 'Tipo':" << jsonObj;
                continue;
            }

            QString tipo = jsonObj["Tipo"].toString();
            Media* media = nullptr;

            if (tipo == "Rivista")
                media = loadRivista(jsonObj);
            else if (tipo == "Film")
                media = loadFilm(jsonObj);
            else if (tipo == "SerieTV")
                media = loadSerieTV(jsonObj);
            else if (tipo == "Libro")
                media = loadLibro(jsonObj);
            else {
                qWarning() << "Tipo di media sconosciuto:" << tipo;
                continue;
            }

            if(media) {
                mediaList.append(media);
            }
        }
    }

    setOggetti(mediaList);
    return mediaList;
}

JsonManager::MediaBase JsonManager::loadMedia(const QJsonObject& jsonObj) {
    JsonManager::MediaBase mediaBase;
    mediaBase.identifier = jsonObj.value("identifier").toInt();
    mediaBase.titolo = jsonObj.value("titolo").toString();
    mediaBase.AnnoPub = jsonObj.value("AnnoPub").toInt();
    mediaBase.descrizione = jsonObj.value("descrizione").toString();
    mediaBase.genere = Enums::stringToMediaGenre(jsonObj.value("genere").toString().toStdString());
    mediaBase.image_path = jsonObj.value("image_path").toString();
    return mediaBase;
}

JsonManager::CartaceoBase JsonManager::loadCartaceo(const QJsonObject& jsonObj) {
    JsonManager::CartaceoBase cartaceoBase;
    cartaceoBase.pagine = jsonObj.value("pagine").toInt();
    cartaceoBase.autore = jsonObj.value("autore").toString();
    cartaceoBase.editore = jsonObj.value("editore").toString();
    return cartaceoBase;
}

JsonManager::MultimediaBase JsonManager::loadMultimedia(const QJsonObject& jsonObj){
    JsonManager::MultimediaBase multimediaBase;
    multimediaBase.regista = jsonObj.value("regista").toString();
    multimediaBase.studioProduzione = jsonObj.value("studioProduzione").toString();

    QString ageRatingStr = jsonObj.value("AgeRating").toString();
    if (ageRatingStr.isEmpty()) {
        multimediaBase.AgeRating = Enums::AgeRating::G;
    } else {
        multimediaBase.AgeRating = Enums::stringToAgeRating(ageRatingStr.toStdString());
    }

    multimediaBase.media_path = jsonObj.value("media_path").toString();
    return multimediaBase;
}

Media* JsonManager::loadRivista(const QJsonObject& obj) {
    JsonManager::MediaBase mediaBase = loadMedia(obj);
    JsonManager::CartaceoBase cartaceoBase = loadCartaceo(obj);
    return new Rivista(
        obj.value("identifier").toInt(),
        obj.value("titolo").toString().toStdString(),
        obj.value("AnnoPub").toInt(),
        obj.value("descrizione").toString().toStdString(),
        Enums::stringToMediaGenre(obj.value("genere").toString().toStdString()),
        obj.value("image_path").toString().toStdString(),
        obj.value("pagine").toInt(),
        obj.value("editore").toString().toStdString(),
        obj.value("autore").toString().toStdString(),
        Enums::stringToLingue(obj.value("lingua").toString().toStdString()),
        obj.value("NumeroSettimanale").toInt()
        );
}

Media* JsonManager::loadFilm(const QJsonObject& obj) {
    JsonManager::MediaBase mediaBase = loadMedia(obj);
    JsonManager::MultimediaBase multimediaBase = loadMultimedia(obj);
    return new Film(
        obj.value("identifier").toInt(),
        obj.value("titolo").toString().toStdString(),
        obj.value("AnnoPub").toInt(),
        obj.value("descrizione").toString().toStdString(),
        Enums::stringToMediaGenre(obj.value("genere").toString().toStdString()),
        obj.value("image_path").toString().toStdString(),
        obj.value("regista").toString().toStdString(),
        obj.value("studioProduzione").toString().toStdString(),
        obj.value("media_path").toString().toStdString(),
        Enums::stringToAgeRating(obj.value("AgeRating").toString().toStdString()),
        obj.value("durataMinuti").toInt(),
        Enums::stringToVideoQuality(obj.value("QualitaVideo").toString().toStdString())
        );
}

Media* JsonManager::loadSerieTV(const QJsonObject& obj) {
    JsonManager::MediaBase mediaBase = loadMedia(obj);
    JsonManager::MultimediaBase multimediaBase = loadMultimedia(obj);
    return new SerieTV(
        obj.value("identifier").toInt(),
        obj.value("titolo").toString().toStdString(),
        obj.value("AnnoPub").toInt(),
        obj.value("descrizione").toString().toStdString(),
        Enums::stringToMediaGenre(obj.value("genere").toString().toStdString()),
        obj.value("image_path").toString().toStdString(),
        obj.value("regista").toString().toStdString(),
        obj.value("studioProduzione").toString().toStdString(),
        obj.value("media_path").toString().toStdString(),
        Enums::stringToAgeRating(obj.value("AgeRating").toString().toStdString()),
        obj.value("stagioni").toInt(),
        obj.value("IsInCorso").toInt()
        );
}

Media* JsonManager::loadLibro(const QJsonObject& obj) {
    JsonManager::MediaBase mediaBase = loadMedia(obj);
    JsonManager::CartaceoBase cartaceoBase = loadCartaceo(obj);
    return new Libro(
        obj.value("identifier").toInt(),
        obj.value("titolo").toString().toStdString(),
        obj.value("AnnoPub").toInt(),
        obj.value("descrizione").toString().toStdString(),
        Enums::stringToMediaGenre(obj.value("genere").toString().toStdString()),
        obj.value("image_path").toString().toStdString(),
        obj.value("pagine").toInt(),
        obj.value("editore").toString().toStdString(),
        obj.value("autore").toString().toStdString(),
        obj.value("ISBN").toString().toStdString(),
        Enums::stringToLingue(obj.value("lingua").toString().toStdString())
        );
}

void JsonManager::deleteObject(Media* media) {
    int occurenceToSkip = 0;
    for (int i = 0; i < repository.size(); ++i) {
        if (repository[i] == media) {
            repository.removeAt(i);
            break;
        }
        if (repository[i]->getTitolo() == media->getTitolo()) {
            occurenceToSkip++;
        }
    }
    repository.removeOne(media);

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Impossibile aprire il file:" << filePath;
        return;
    }

    QByteArray data = file.readAll();
    QJsonDocument doc = QJsonDocument::fromJson(data);

    if (!doc.isArray() || doc.isNull()) {
        qWarning() << "Il file JSON non contiene un array di oggetti.";
        return;
    }
    QJsonArray jsonArray = doc.array();
    QJsonArray newArray;
    int occurence = 0;
    for (int i = 0; i < jsonArray.size(); ++i) {
        QJsonObject obj = jsonArray[i].toObject();
        if (obj.value("titolo").toString() == QString::fromStdString(media->getTitolo())) {
            if (occurence == occurenceToSkip) {
                occurence++;
                continue; // Salta questo oggetto
            }
            occurence++;
        }
        newArray.append(obj);
    }
    file.close();
    if (!file.open(QIODevice::WriteOnly )) {
        qWarning() << "Impossibile aprire il file in scrittura:" << filePath;
        return;
    }
    else
    {
        QJsonDocument newDoc(newArray);
        file.write(newDoc.toJson());
        file.close();
    }
    delete media;
}

void JsonManager::updateObject(Media* media) {
    if(!media){
        qWarning() << "Media object is null.";
        return;
    }

    // Leggi il file JSON esistente
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Impossibile aprire il file:" << filePath;
        return;
    }

    QByteArray data = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isArray() || doc.isNull()) {
        qWarning() << "Il file JSON non contiene un array di oggetti.";
        return;
    }

    QJsonArray jsonArray = doc.array();
    QJsonArray newArray;
    bool mediaUpdated = false;

    // Cerca il media da aggiornare per identifier
    for (const QJsonValue& value : jsonArray) {
        if (value.isObject()) {
            QJsonObject obj = value.toObject();
            int mediaId = obj["identifier"].toInt();

            if (mediaId == static_cast<int>(media->getIdentifier())) {
                QJsonObject updatedObject;

                if (dynamic_cast<Libro*>(media)) {
                    updatedObject = save(static_cast<Libro*>(media));
                } else if (dynamic_cast<Rivista*>(media)) {
                    updatedObject = save(static_cast<Rivista*>(media));
                } else if (dynamic_cast<Film*>(media)) {
                    updatedObject = save(static_cast<Film*>(media));
                } else if (dynamic_cast<SerieTV*>(media)) {
                    updatedObject = save(static_cast<SerieTV*>(media));
                }

                newArray.append(updatedObject);
                mediaUpdated = true;
            } else {
                newArray.append(obj);
            }
        }
    }

    if (!mediaUpdated) {
        QJsonObject newObject;

        if (dynamic_cast<Libro*>(media)) {
            newObject = save(static_cast<Libro*>(media));
        } else if (dynamic_cast<Rivista*>(media)) {
            newObject = save(static_cast<Rivista*>(media));
        } else if (dynamic_cast<Film*>(media)) {
            newObject = save(static_cast<Film*>(media));
        } else if (dynamic_cast<SerieTV*>(media)) {
            newObject = save(static_cast<SerieTV*>(media));
        }

        newArray.append(newObject);
    }

    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QJsonDocument newDoc(newArray);
        file.write(newDoc.toJson());
        file.close();
    } else {
        qWarning() << "Impossibile aprire il file in scrittura:" << filePath;
    }
}

void JsonManager::save(Media* media, QJsonObject& jsonObj) {
    jsonObj["identifier"] = static_cast<int>(media->getIdentifier());
    jsonObj["titolo"] = QString::fromStdString(media->getTitolo());
    jsonObj["AnnoPub"] = media->getAnnoPub();
    jsonObj["descrizione"] = QString::fromStdString(media->getDescrizione());
    jsonObj["genere"] = QString::fromStdString(Enums::mediaGenreToString(media->getGenere()));
    jsonObj["image_path"] = QString::fromStdString(media->getImagePath());
}

void JsonManager::save(Cartaceo* cartaceo, QJsonObject& jsonObj) {
    jsonObj["pagine"] = cartaceo->getPagine();
    jsonObj["autore"] = QString::fromStdString(cartaceo->getAutore());
    jsonObj["editore"] = QString::fromStdString(cartaceo->getEditore());
}

void JsonManager::save(Multimedia* multimedia, QJsonObject& jsonObj) {
    jsonObj["regista"] = QString::fromStdString(multimedia->getRegista());
    jsonObj["studioProduzione"] = QString::fromStdString(multimedia->getStudioProduzione());
    jsonObj["media_path"] = QString::fromStdString(multimedia->getMediaPath());
    jsonObj["AgeRating"] = QString::fromStdString(Enums::ageRatingToString(multimedia->getAgeRating()));
}

QJsonObject JsonManager::save(Libro* libro) {
    QJsonObject baseObj;
    baseObj["Tipo"] = "Libro";
    save(static_cast<Media*>(libro), baseObj);
    Cartaceo* cartaceo = dynamic_cast<Cartaceo*>(libro);
    if (cartaceo) {
        save(cartaceo, baseObj);
    }
    baseObj["ISBN"] = QString::fromStdString(libro->getISBN());
    baseObj["lingua"] = QString::fromStdString(Enums::lingueToString(libro->getLingua()));
    return baseObj;
}

QJsonObject JsonManager::save(Rivista* rivista) {
    QJsonObject baseObj;
    baseObj["Tipo"] = "Rivista";
    save(static_cast<Media*>(rivista), baseObj);
    Cartaceo* cartaceo = dynamic_cast<Cartaceo*>(rivista);
    if (cartaceo) {
        save(cartaceo, baseObj);
    }
    baseObj["lingua"] = QString::fromStdString(Enums::lingueToString(rivista->getLingua()));
    baseObj["NumeroSettimanale"] = rivista->getNumeroSettimanale();
    return baseObj;
}

QJsonObject JsonManager::save(Film* film) {
    QJsonObject baseObj;
    baseObj["Tipo"] = "Film";
    save(static_cast<Media*>(film), baseObj);
    Multimedia* multimedia = dynamic_cast<Multimedia*>(film);
    if (multimedia) {
        save(multimedia, baseObj);
    }
    baseObj["durataMinuti"] = film->getDurataMinuti();
    baseObj["QualitaVideo"] = QString::fromStdString(Enums::videoQualityToString(film->getQualitaVideo()));
    return baseObj;
}

QJsonObject JsonManager::save(SerieTV* serieTV) {
    QJsonObject baseObj;
    baseObj["Tipo"] = "SerieTV";
    save(static_cast<Media*>(serieTV), baseObj);
    Multimedia* multimedia = dynamic_cast<Multimedia*>(serieTV);
    if (multimedia) {
        save(multimedia, baseObj);
    }
    baseObj["stagioni"] = serieTV->getStagioni();
    baseObj["IsInCorso"] = serieTV->getIsInCorso();
    return baseObj;
}

void JsonManager::savenewObject(Media* media) {
    if (!media) {
        qWarning() << "Tentativo di salvare un media nullo.";
        return;
    }

    QFile file(filePath);
    QJsonArray jsonArray;

    // Carica array esistente se il file c'è ed è valido
    if (file.exists() && file.open(QIODevice::ReadOnly)) {
        QByteArray data = file.readAll();
        file.close();

        QJsonDocument doc = QJsonDocument::fromJson(data);
        if (doc.isArray()) {
            jsonArray = doc.array();
        }
    }

    int newId = static_cast<int>(media->getIdentifier());

    QSet<int> usedIds;
    for (const QJsonValue& value : jsonArray) {
        if (value.isObject()) {
            int existingId = value.toObject()["identifier"].toInt();
            usedIds.insert(existingId);
        }
    }

    if (usedIds.contains(newId)) {
        qWarning() << "Identifier duplicato trovato:" << newId;

        // Trova il primo ID libero
        int candidateId = 1;
        while (usedIds.contains(candidateId)) {
            candidateId++;
        }

        qWarning() << "Assegnato nuovo identifier:" << candidateId;
        media->setIdentifier(candidateId);
        newId = candidateId;
    }

    // Crea l'oggetto JSON corretto in base al tipo
    QJsonObject newObject;
    if (dynamic_cast<Libro*>(media)) {
        newObject = save(static_cast<Libro*>(media));
    } else if (dynamic_cast<Rivista*>(media)) {
        newObject = save(static_cast<Rivista*>(media));
    } else if (dynamic_cast<Film*>(media)) {
        newObject = save(static_cast<Film*>(media));
    } else if (dynamic_cast<SerieTV*>(media)) {
        newObject = save(static_cast<SerieTV*>(media));
    } else {
        qWarning() << "Tipo di media sconosciuto, impossibile salvare.";
        return;
    }

    // Aggiungi all'array e riscrivi il file
    jsonArray.append(newObject);

    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QJsonDocument newDoc(jsonArray);
        file.write(newDoc.toJson());
        file.close();
        qDebug() << "Nuovo media salvato in" << filePath;
    } else {
        qWarning() << "Impossibile aprire il file in scrittura:" << filePath;
    }
}

void JsonManager::debugJsonStructure() {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Impossibile aprire il file per debug:" << filePath;
        return;
    }

    QByteArray data = file.readAll();
    file.close();

    qDebug() << "Contenuto JSON:";
    qDebug() << data;

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (doc.isArray()) {
        QJsonArray array = doc.array();
        qDebug() << "Numero di elementi:" << array.size();
        for (int i = 0; i < array.size(); ++i) {
            if (array[i].isObject()) {
                QJsonObject obj = array[i].toObject();
                qDebug() << "Elemento" << i << ":" << obj;
            }
        }
    }
}


