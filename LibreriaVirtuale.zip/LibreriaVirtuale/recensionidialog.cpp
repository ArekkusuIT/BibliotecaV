#include "recensionidialog.h"
#include <QVBoxLayout>
#include <QHeaderView>
#include "QPushButton"

RecensioniDialog::RecensioniDialog(const std::vector<Recensioni>& recensioni, QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("Recensioni");
    resize(500, 300);

    QVBoxLayout* layout = new QVBoxLayout(this);

    table = new QTableWidget(this);
    table->setColumnCount(2);
    table->setHorizontalHeaderLabels({"Fonte", "Valutazione"});
    table->setRowCount(recensioni.size());

    for (size_t i = 0; i < recensioni.size(); ++i) {
        table->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(recensioni[i].getFonte())));
        table->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(recensioni[i].getValutazione())));
    }

    table->horizontalHeader()->setStretchLastSection(true);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    layout->addWidget(table);

    QPushButton* closeButton = new QPushButton("Chiudi", this);
    connect(closeButton, &QPushButton::clicked, this, &QDialog::accept);
    layout->addWidget(closeButton);
}
