#include "recensioni.h"


Recensioni::Recensioni(const std::string& fonte, const std::string& valutazione)
    : fonte(fonte), valutazione(valutazione) {}


std::string Recensioni::getFonte() const {
    return fonte;

}

std::string Recensioni::getValutazione() const {
    return valutazione;
}

Recensioni& Recensioni::setFonte(const std::string& fonte) {
    this->fonte = fonte;
    return *this;
}

Recensioni& Recensioni::setValutazione(const std::string& valutazione) {
    this->valutazione = valutazione;
    return *this;
};
