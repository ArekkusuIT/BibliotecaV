#include "bconstvisitor.h"

BConstVisitor::BConstVisitor() {}
