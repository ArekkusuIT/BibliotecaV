#include "media.h"
#include "QDebug"

Media::Media(const unsigned int identifier,
             std::string titolo,
             int AnnoPub,
             std::string descrizione,
             Enums::MediaGenre genere,
             std::string image_path ) :

    identifier(identifier), titolo(titolo), AnnoPub(AnnoPub), descrizione(descrizione), genere(genere), image_path(image_path)
{
    qDebug() << "Media creato con id:" << identifier << ", titolo:" << QString::fromStdString(titolo);
}
Media::~Media(){
    qDebug() << "Media distrutto con id:" << identifier << ", titolo:" << QString::fromStdString(titolo);
}

unsigned int Media::getIdentifier() const{
    return identifier;
}

Media& Media::setIdentifier(const unsigned int identifier){
    this->identifier = identifier;
    return *this;
}
std::string Media::getTitolo() const{
    return titolo;
}

Media& Media::setTitolo(const std::string titolo){
    this->titolo = titolo;
    return *this;
}

int Media::getAnnoPub() const{
    return AnnoPub;
}

Media& Media::setAnnoPub(const int annoPub){
    this->AnnoPub = annoPub;
    return *this;
}

std::string Media::getDescrizione() const{
    return descrizione;
}

Media& Media::setDescrizione(const std::string descrizione){
    this->descrizione = descrizione;
    return *this;
}

Enums::MediaGenre Media::getGenere() const{
    return genere;
}

Media& Media::setGenere(const Enums::MediaGenre genere){
    this->genere = genere;
    return *this;
}

std::string Media::getImagePath() const{
    return image_path;
}

Media& Media::setImagePath(const std::string image_path){
    this->image_path = image_path;
    return *this;
}

