/****************************************************************************
** Meta object code from reading C++ file 'fullmedia.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../fullmedia.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fullmedia.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_FullMedia_t {
    const uint offsetsAndSize[28];
    char stringdata0[168];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_FullMedia_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_FullMedia_t qt_meta_stringdata_FullMedia = {
    {
QT_MOC_LITERAL(0, 9), // "FullMedia"
QT_MOC_LITERAL(10, 14), // "showEditWindow"
QT_MOC_LITERAL(25, 0), // ""
QT_MOC_LITERAL(26, 10), // "identifier"
QT_MOC_LITERAL(37, 11), // "deleteMedia"
QT_MOC_LITERAL(49, 14), // "showRecensioni"
QT_MOC_LITERAL(64, 23), // "std::vector<Recensioni>"
QT_MOC_LITERAL(88, 10), // "recensioni"
QT_MOC_LITERAL(99, 11), // "displayInfo"
QT_MOC_LITERAL(111, 5), // "Media"
QT_MOC_LITERAL(117, 5), // "media"
QT_MOC_LITERAL(123, 25), // "onRecensioniButtonClicked"
QT_MOC_LITERAL(149, 11), // "std::string"
QT_MOC_LITERAL(161, 6) // "titolo"

    },
    "FullMedia\0showEditWindow\0\0identifier\0"
    "deleteMedia\0showRecensioni\0"
    "std::vector<Recensioni>\0recensioni\0"
    "displayInfo\0Media\0media\0"
    "onRecensioniButtonClicked\0std::string\0"
    "titolo"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FullMedia[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   44,    2, 0x06,    1 /* Public */,
       4,    1,   47,    2, 0x06,    3 /* Public */,
       5,    1,   50,    2, 0x06,    5 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    1,   53,    2, 0x0a,    7 /* Public */,
      11,    1,   56,    2, 0x0a,    9 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::UInt,    3,
    QMetaType::Void, QMetaType::UInt,    3,
    QMetaType::Void, 0x80000000 | 6,    7,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 12,   13,

       0        // eod
};

void FullMedia::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FullMedia *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showEditWindow((*reinterpret_cast< std::add_pointer_t<uint>>(_a[1]))); break;
        case 1: _t->deleteMedia((*reinterpret_cast< std::add_pointer_t<uint>>(_a[1]))); break;
        case 2: _t->showRecensioni((*reinterpret_cast< std::add_pointer_t<std::vector<Recensioni>>>(_a[1]))); break;
        case 3: _t->displayInfo((*reinterpret_cast< std::add_pointer_t<Media>>(_a[1]))); break;
        case 4: _t->onRecensioniButtonClicked((*reinterpret_cast< std::add_pointer_t<std::string>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FullMedia::*)(unsigned int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FullMedia::showEditWindow)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FullMedia::*)(unsigned int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FullMedia::deleteMedia)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FullMedia::*)(const std::vector<Recensioni> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FullMedia::showRecensioni)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject FullMedia::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_FullMedia.offsetsAndSize,
    qt_meta_data_FullMedia,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_FullMedia_t
, QtPrivate::TypeAndForceComplete<FullMedia, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<unsigned int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<unsigned int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const std::vector<Recensioni> &, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const Media &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const std::string &, std::false_type>


>,
    nullptr
} };


const QMetaObject *FullMedia::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FullMedia::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FullMedia.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "BConstVisitor"))
        return static_cast< BConstVisitor*>(this);
    return QWidget::qt_metacast(_clname);
}

int FullMedia::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void FullMedia::showEditWindow(unsigned int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void FullMedia::deleteMedia(unsigned int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void FullMedia::showRecensioni(const std::vector<Recensioni> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
