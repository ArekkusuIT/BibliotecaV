#include "QVBoxLayout"
#include "QLineEdit"
#include "QPushButton"

#include "SearchWidget.h"

SearchWidget::SearchWidget(QWidget *parent)
    : QWidget(parent)
{
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    searchItemBar = new QLineEdit(this);
    searchItemBar->setPlaceholderText("Cerca qui...");
    mainLayout->addWidget(searchItemBar);

    searchTime = new QTimer(this);

    QPushButton *searchButton = new QPushButton("Search", this);
    mainLayout->addWidget(searchButton);

    connect(searchButton, &QPushButton::clicked, this, [this](){
        searchTime->start(1000); // Delay of 1000 ms
    });

    connect(searchTime, &QTimer::timeout, this, [this](){
        emit searchRequested(searchItemBar->text());
    });
}
