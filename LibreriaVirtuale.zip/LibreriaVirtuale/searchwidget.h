#ifndef SEARCHWIDGET_H
#define SEARCHWIDGET_H


#include <QWidget>
#include <QLineEdit>
#include <QSpinBox>
#include <QTimer>
#include "QPushButton"
#include "QHBoxLayout"
#include "QComboBox"
#include "media.h"

class SearchWidget: public QWidget
{
    Q_OBJECT
private:
    QPushButton* searchButton;
    QLineEdit* searchMediaBar;
    QTimer* searchTime;
    QPushButton* clearButton;
private slots:
    void onSearchClicked();
    void onClearClicked();
public:
    explicit SearchWidget(QWidget *parent = 0);

    QString getSearchText() const;
    void clearSearch();
signals:
    void searchRequested(const QString& searchText);
    void searchCleared();
};


#endif // SEARCHWIDGET_H
