#include "cartaceo.h"


Cartaceo::Cartaceo(const unsigned int identifier,
                   std::string titolo,
                   int AnnoPub,
                   std::string descrizione,
                   Enums::MediaGenre genere,
                   std::string image_path,
                   int pagine,
                   std::string editore,
                   std::string autore ) :

    Media(identifier, titolo, AnnoPub, descrizione, genere, image_path), pagine(pagine), editore(editore), autore(autore)
{}

int Cartaceo::getPagine() const{
    return pagine;
}
Cartaceo& Cartaceo::setPagine(const int pagine){
    this->pagine = pagine;
    return *this;
}
std::string Cartaceo::getEditore() const{
    return editore;
}
Cartaceo& Cartaceo::setEditore(const std::string editore){
    this->editore = editore;
    return *this;
}
std::string Cartaceo::getAutore() const{
    return autore;
}
Cartaceo& Cartaceo::setAutore(const std::string autore){
    this->autore = autore;
    return *this;
}

