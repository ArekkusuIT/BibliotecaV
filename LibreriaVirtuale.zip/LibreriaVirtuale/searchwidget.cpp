#include "searchwidget.h"
#include <QLabel>
#include <QHBoxLayout>

SearchWidget::SearchWidget(QWidget *parent)
    : QWidget(parent){
    QHBoxLayout* layout = new QHBoxLayout(this);

    searchMediaBar = new QLineEdit(this);
    searchMediaBar->setPlaceholderText("Cerca qui il tuo media. . .");
    searchMediaBar->setClearButtonEnabled(true);

    searchButton = new QPushButton(QIcon(":icons/Images_PAO/filter_icon.png"), "Cerca", this);

    clearButton = new QPushButton(QIcon(":icons/Images_PAO/clean.png"),"Pulisci",this);
    clearButton->setVisible(false);

    layout->addWidget(searchMediaBar);
    layout->addWidget(searchButton);
    layout->addWidget(clearButton);

    connect(searchButton, &QPushButton::clicked, this, &SearchWidget::onSearchClicked);
    connect(clearButton, &QPushButton::clicked, this, &SearchWidget::onClearClicked);
    connect(searchMediaBar, &QLineEdit::returnPressed, this, &SearchWidget::onSearchClicked);
}

QString SearchWidget::getSearchText() const{
    return searchMediaBar->text().trimmed();
}

void SearchWidget::clearSearch(){
    searchMediaBar->clear();
    emit searchCleared();
}

void SearchWidget::onSearchClicked(){
    QString text = getSearchText();
    if(!text.isEmpty()){
        emit searchRequested(text);
        clearButton->setVisible(true);
    }
}

void SearchWidget::onClearClicked(){
    clearSearch();
    emit searchCleared();
}
