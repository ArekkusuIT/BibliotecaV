#include "multimedia.h"

#include "vector"


Multimedia::Multimedia(const unsigned int identifier,
                       std::string titolo,
                       int AnnoPub,
                       std::string descrizione,
                       Enums::MediaGenre genere,
                       std::string image_path,
                       std::string regista,
                       std::string studioProduzione,
                       std::string media_path,
                       Enums::AgeRating AgeRating):

    Media(identifier, titolo, AnnoPub, descrizione, genere, image_path), regista(regista), studioProduzione(studioProduzione), media_path(media_path), AgeRating(AgeRating)
{}

std::string Multimedia::getRegista() const{
    return regista;
}

Multimedia& Multimedia::setRegista(const std::string regista){
    this->regista = regista;
    return *this;
}

std::string Multimedia::getStudioProduzione() const{
    return studioProduzione;
}

Multimedia& Multimedia::setStudioProduzione(const std::string studioProduzione){
    this->studioProduzione = studioProduzione;
    return *this;
}

std::vector<Recensioni*> Multimedia::getRatings() const{
    return ratings;
}

Multimedia& Multimedia::setRatings(const Recensioni* rating){
    ratings.push_back(new Recensioni(*rating));
    return *this;
}

std::string Multimedia::getMediaPath() const{
    return media_path;
}

Multimedia& Multimedia::setMediaPath(const std::string media_path){
    this->media_path = media_path;
    return *this;
}

Enums::AgeRating Multimedia::getAgeRating() const{
    return AgeRating;
}

Multimedia& Multimedia::setAgeRating(const Enums::AgeRating AgeRating){
    this->AgeRating = AgeRating;
    return *this;
}

