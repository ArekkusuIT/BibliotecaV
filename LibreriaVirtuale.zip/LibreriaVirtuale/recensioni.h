#ifndef RECENSIONI_H
#define RECENSIONI_H

#include <string>

class Recensioni
{
private:
    std::string fonte;
    std::string valutazione;
public:
    Recensioni(const std::string& fonte, const std::string& valutazione);
    std::string getFonte() const;
    Recensioni& setFonte(const std::string& fonte);
    std::string getValutazione() const;
    Recensioni& setValutazione(const std::string& valutazione);
};

#endif // RECENSIONI_H
