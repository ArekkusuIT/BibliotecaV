/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[66];
    char stringdata0[479];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 14), // "showMainScreen"
QT_MOC_LITERAL(26, 0), // ""
QT_MOC_LITERAL(27, 18), // "onMediaItemClicked"
QT_MOC_LITERAL(46, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(63, 4), // "item"
QT_MOC_LITERAL(68, 19), // "onEditButtonClicked"
QT_MOC_LITERAL(88, 21), // "onDeleteButtonClicked"
QT_MOC_LITERAL(110, 14), // "handleNewMedia"
QT_MOC_LITERAL(125, 6), // "Media*"
QT_MOC_LITERAL(132, 5), // "media"
QT_MOC_LITERAL(138, 17), // "handleMediaUpdate"
QT_MOC_LITERAL(156, 17), // "onSearchRequested"
QT_MOC_LITERAL(174, 10), // "searchText"
QT_MOC_LITERAL(185, 15), // "onSearchCleared"
QT_MOC_LITERAL(201, 26), // "onDescrizioneButtonClicked"
QT_MOC_LITERAL(228, 25), // "onRecensioniButtonClicked"
QT_MOC_LITERAL(254, 22), // "onTrailerButtonClicked"
QT_MOC_LITERAL(277, 14), // "onMediaUpdated"
QT_MOC_LITERAL(292, 11), // "createMedia"
QT_MOC_LITERAL(304, 9), // "editMedia"
QT_MOC_LITERAL(314, 10), // "identifier"
QT_MOC_LITERAL(325, 15), // "getMediaDetails"
QT_MOC_LITERAL(341, 11), // "deleteMedia"
QT_MOC_LITERAL(353, 14), // "addMediaToList"
QT_MOC_LITERAL(368, 5), // "Media"
QT_MOC_LITERAL(374, 13), // "openMediaFile"
QT_MOC_LITERAL(388, 13), // "saveMediaFile"
QT_MOC_LITERAL(402, 15), // "closeEditWindow"
QT_MOC_LITERAL(418, 18), // "createNewMediaFile"
QT_MOC_LITERAL(437, 13), // "showShortcuts"
QT_MOC_LITERAL(451, 15), // "showDescrizione"
QT_MOC_LITERAL(467, 11) // "descrizione"

    },
    "MainWindow\0showMainScreen\0\0"
    "onMediaItemClicked\0QListWidgetItem*\0"
    "item\0onEditButtonClicked\0onDeleteButtonClicked\0"
    "handleNewMedia\0Media*\0media\0"
    "handleMediaUpdate\0onSearchRequested\0"
    "searchText\0onSearchCleared\0"
    "onDescrizioneButtonClicked\0"
    "onRecensioniButtonClicked\0"
    "onTrailerButtonClicked\0onMediaUpdated\0"
    "createMedia\0editMedia\0identifier\0"
    "getMediaDetails\0deleteMedia\0addMediaToList\0"
    "Media\0openMediaFile\0saveMediaFile\0"
    "closeEditWindow\0createNewMediaFile\0"
    "showShortcuts\0showDescrizione\0descrizione"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  152,    2, 0x08,    1 /* Private */,
       3,    1,  153,    2, 0x08,    2 /* Private */,
       6,    0,  156,    2, 0x08,    4 /* Private */,
       7,    0,  157,    2, 0x08,    5 /* Private */,
       8,    1,  158,    2, 0x08,    6 /* Private */,
      11,    0,  161,    2, 0x08,    8 /* Private */,
      12,    1,  162,    2, 0x08,    9 /* Private */,
      14,    0,  165,    2, 0x08,   11 /* Private */,
      15,    0,  166,    2, 0x08,   12 /* Private */,
      16,    0,  167,    2, 0x08,   13 /* Private */,
      17,    0,  168,    2, 0x08,   14 /* Private */,
      18,    1,  169,    2, 0x08,   15 /* Private */,
      19,    0,  172,    2, 0x0a,   17 /* Public */,
      20,    1,  173,    2, 0x0a,   18 /* Public */,
      22,    1,  176,    2, 0x0a,   20 /* Public */,
      23,    1,  179,    2, 0x0a,   22 /* Public */,
      24,    1,  182,    2, 0x0a,   24 /* Public */,
      26,    0,  185,    2, 0x0a,   26 /* Public */,
      27,    0,  186,    2, 0x0a,   27 /* Public */,
      28,    0,  187,    2, 0x0a,   28 /* Public */,
      29,    0,  188,    2, 0x0a,   29 /* Public */,
      30,    0,  189,    2, 0x0a,   30 /* Public */,
      31,    1,  190,    2, 0x0a,   31 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt,   21,
    QMetaType::Void, QMetaType::UInt,   21,
    QMetaType::Void, QMetaType::UInt,   21,
    QMetaType::Void, 0x80000000 | 25,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   32,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showMainScreen(); break;
        case 1: _t->onMediaItemClicked((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 2: _t->onEditButtonClicked(); break;
        case 3: _t->onDeleteButtonClicked(); break;
        case 4: _t->handleNewMedia((*reinterpret_cast< std::add_pointer_t<Media*>>(_a[1]))); break;
        case 5: _t->handleMediaUpdate(); break;
        case 6: _t->onSearchRequested((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->onSearchCleared(); break;
        case 8: _t->onDescrizioneButtonClicked(); break;
        case 9: _t->onRecensioniButtonClicked(); break;
        case 10: _t->onTrailerButtonClicked(); break;
        case 11: _t->onMediaUpdated((*reinterpret_cast< std::add_pointer_t<Media*>>(_a[1]))); break;
        case 12: _t->createMedia(); break;
        case 13: _t->editMedia((*reinterpret_cast< std::add_pointer_t<uint>>(_a[1]))); break;
        case 14: _t->getMediaDetails((*reinterpret_cast< std::add_pointer_t<uint>>(_a[1]))); break;
        case 15: _t->deleteMedia((*reinterpret_cast< std::add_pointer_t<uint>>(_a[1]))); break;
        case 16: _t->addMediaToList((*reinterpret_cast< std::add_pointer_t<Media>>(_a[1]))); break;
        case 17: _t->openMediaFile(); break;
        case 18: _t->saveMediaFile(); break;
        case 19: _t->closeEditWindow(); break;
        case 20: _t->createNewMediaFile(); break;
        case 21: _t->showShortcuts(); break;
        case 22: _t->showDescrizione((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Media *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Media *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<unsigned int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<unsigned int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<unsigned int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const Media &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
