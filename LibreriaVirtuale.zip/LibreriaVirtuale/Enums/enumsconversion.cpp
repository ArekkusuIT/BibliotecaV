#include "stdexcept"

#include "Enums/enumsconversion.h"

namespace Enums{
string mediaGenreToString(const MediaGenre& genre){
    switch(genre){
    case MediaGenre::Fantascienza:
        return "Fantascienza";
    case MediaGenre::Fantasy:
        return "Fantasy";
    case MediaGenre::Horror:
        return "Horror";
    case MediaGenre::Commedia:
        return "Commedia";
    case MediaGenre::Drammatico:
        return "Drammatico";
    case MediaGenre::Documentario:
        return "Documentario";
    case MediaGenre::Thriller:
        return "Thriller";
    case MediaGenre::Romantico:
        return "Romantico";
    case MediaGenre::Avventura:
        return "Avventura";
    case MediaGenre::Animazione:
        return "Animazione";
    case MediaGenre::Storico:
        return "Storico";
    case MediaGenre::Biografico:
        return "Biografico";
    case MediaGenre::Musicale:
        return "Musicale";
    case MediaGenre::Guerra:
        return "Guerra";
    case MediaGenre::Western:
        return "Western";
    default:
        throw std::invalid_argument("Genere di media sconosciuto");
    }
}

MediaGenre stringToMediaGenre(const string& str){
    if(str == "Fantascienza")
        return MediaGenre::Fantascienza;
    else if(str == "Fantasy")
        return MediaGenre::Fantasy;
    else if(str == "Horror")
        return MediaGenre::Horror;
    else if(str == "Commedia")
        return MediaGenre::Commedia;
    else if(str == "Drammatico")
        return MediaGenre::Drammatico;
    else if(str == "Documentario")
        return MediaGenre::Documentario;
    else if(str == "Thriller")
        return MediaGenre::Thriller;
    else if(str == "Romantico")
        return MediaGenre::Romantico;
    else if(str == "Avventura")
        return MediaGenre::Avventura;
    else if(str == "Animazione")
        return MediaGenre::Animazione;
    else if(str == "Storico")
        return MediaGenre::Storico;
    else if(str == "Biografico")
        return MediaGenre::Biografico;
    else if(str == "Musicale")
        return MediaGenre::Musicale;
    else if(str == "Guerra")
        return MediaGenre::Guerra;
    else if(str == "Western")
        return MediaGenre::Western;
    else
        throw std::invalid_argument("Genere di media sconosciuto: " + str);
}

string ageRatingToString(const AgeRating& rating){
    switch(rating){
    case AgeRating::G:
        return "G";
    case AgeRating::PG:
        return "PG";
    case AgeRating::PG13:
        return "PG-13";
    case AgeRating::R:
        return "R";
    case AgeRating::NC17:
        return "NC-17";
    default:
        throw std::invalid_argument("Classificazione per eta' sconosciuta");
    }
}

AgeRating stringToAgeRating(const string& str){
    if(str == "G")
        return AgeRating::G;
    else if(str == "PG")
        return AgeRating::PG;
    else if(str == "PG-13")
        return AgeRating::PG13;
    else if(str == "R")
        return AgeRating::R;
    else if(str == "NC-17")
        return AgeRating::NC17;
    else
        throw std::invalid_argument("Classificazione per eta' sconosciuta: " + str);
}

string videoQualityToString(const VideoQuality& quality){
    switch(quality){
    case VideoQuality::SD:
        return "SD";
    case VideoQuality::HD:
        return "HD";
    case VideoQuality::FHD:
        return "FHD";
    case VideoQuality::UHD:
        return "UHD";
    case VideoQuality::HDR:
        return "HDR";
    default:
        throw std::invalid_argument("Qualita' video sconosciuta");
    }
}

VideoQuality stringToVideoQuality(const string& str){
    if(str == "SD")
        return VideoQuality::SD;
    else if(str == "HD")
        return VideoQuality::HD;
    else if(str == "FHD")
        return VideoQuality::FHD;
    else if(str == "UHD")
        return VideoQuality::UHD;
    else if(str == "HDR")
        return VideoQuality::HDR;
    else
        throw std::invalid_argument("Qualita' video sconosciuta: " + str);
}

string lingueToString(const Lingue& lingua){
    switch(lingua){
    case Lingue::Italiano:
        return "Italiano";
    case Lingue::Inglese:
        return "Inglese";
    case Lingue::Spagnolo:
        return "Spagnolo";
    case Lingue::Francese:
        return "Francese";
    case Lingue::Tedesco:
        return "Tedesco";
    case Lingue::Cinese:
        return "Cinese";
    case Lingue::Giapponese:
        return "Giapponese";
    case Lingue::Russo:
        return "Russo";
    case Lingue::Arabo:
        return "Arabo";
    case Lingue::Portoghese:
        return "Portoghese";
    case Lingue::Altro:
        return "Altro";
    default:
        throw std::invalid_argument("Lingua sconosciuta");
    }
}

Lingue stringToLingue(const string& str){
    if(str == "Italiano")
        return Lingue::Italiano;
    else if(str == "Inglese")
        return Lingue::Inglese;
    else if(str == "Spagnolo")
        return Lingue::Spagnolo;
    else if(str == "Francese")
        return Lingue::Francese;
    else if(str == "Tedesco")
        return Lingue::Tedesco;
    else if(str == "Cinese")
        return Lingue::Cinese;
    else if(str == "Giapponese")
        return Lingue::Giapponese;
    else if(str == "Russo")
        return Lingue::Russo;
    else if(str == "Arabo")
        return Lingue::Arabo;
    else if(str == "Portoghese")
        return Lingue::Portoghese;
    else if(str == "Altro")
        return Lingue::Altro;
    else
        throw std::invalid_argument("Lingua sconosciuta: " + str);
}

}
