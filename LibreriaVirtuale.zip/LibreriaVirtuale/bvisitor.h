#ifndef BVISITOR_H
#define BVISITOR_H

class Libro;
class Rivista;
class SerieTV;
class Film;

class BVisitor{
public:
    virtual ~BVisitor() {};
    virtual void visit(Libro& Libro) = 0;
    virtual void visit(Rivista& Rivista) = 0;
    virtual void visit(SerieTV& SerieTV) = 0;
    virtual void visit(Film& Film) = 0;
};

#endif // BVISITOR_H
