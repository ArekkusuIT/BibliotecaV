#ifndef MULTIMEDIA_H
#define MULTIMEDIA_H

#include <string>
#include "vector"
#include "media.h"
#include "recensioni.h"
#include "Enums/mediaenums.h"

class Multimedia : public Media
{
private:
    std::string regista;
    std::string studioProduzione;
    std::vector<Recensioni*> ratings = {};
    std::string media_path;
    Enums::AgeRating AgeRating;
public:
    Multimedia(const unsigned int identifier,
               std::string titolo,
               int AnnoPub,
               std::string descrizione,
               Enums::MediaGenre genere,
               std::string image_path,
               std::string regista,
               std::string studioProduzione,
               std::string media_path,
               Enums::AgeRating AgeRating);

    std::string getRegista() const;
    Multimedia& setRegista(const std::string regista);
    std::string getStudioProduzione() const;
    Multimedia& setStudioProduzione(const std::string studioProduzione);
    std::vector<Recensioni*> getRatings() const;
    Multimedia& setRatings(const Recensioni* rating);
    std::string getMediaPath() const;
    Multimedia& setMediaPath(const std::string media_path);
    Enums::AgeRating getAgeRating() const;
    Multimedia& setAgeRating(const Enums::AgeRating AgeRating);

    virtual ~Multimedia() = default;
};

#endif // MULTIMEDIA_H
