#ifndef REVIEWSERVICE_H
#define REVIEWSERVICE_H

#include <QObject>
#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>


#include "media.h"
#include "multimedia.h"
#include "recensioni.h"

class ReviewService : public QObject {
    Q_OBJECT
public:
    explicit ReviewService(QObject* parent = nullptr);
    void fetchRecensioni(const std::string& titolo);

signals:
    void recensioniPronte(const std::vector<Recensioni>& recensioni);

private:
    QNetworkAccessManager* manager;
};

#endif // REVIEWSERVICE_H
