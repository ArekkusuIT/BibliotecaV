#ifndef ENUMSCONVERSION_H
#define ENUMSCONVERSION_H

#include "mediaenums.h"
#include "string"

using std::string;

namespace Enums{
MediaGenre stringToMediaGenre(const string& str);
string mediaGenreToString(const MediaGenre& genre);

AgeRating stringToAgeRating(const string& str);
string ageRatingToString(const AgeRating& rating);

VideoQuality stringToVideoQuality(const string& str);
string videoQualityToString(const VideoQuality& quality);

Lingue stringToLingue(const string& str);
string lingueToString(const Lingue& lingua);
}
#endif // ENUMSCONVERSION_H
