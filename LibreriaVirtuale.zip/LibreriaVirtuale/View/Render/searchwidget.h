#ifndef SEARCHWIDGET_H
#define SEARCHWIDGET_H


#include <QWidget>
#include <QLineEdit>
#include <QSpinBox>
#include <QTimer>

class SearchWidget: public QWidget
{
    Q_OBJECT
private:
    QLineEdit* searchItemBar;
    QTimer* searchTime;

public:
    explicit SearchWidget(QWidget *parent = 0);
signals:
    void searchRequested(const QString& query);

};

#endif // SEARCHWIDGET_H
