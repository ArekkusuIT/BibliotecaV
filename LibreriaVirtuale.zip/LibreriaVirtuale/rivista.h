#ifndef RIVISTA_H
#define RIVISTA_H

#include "cartaceo.h"
#include "Enums/mediaenums.h"
#include "string"

class Rivista: public Cartaceo
{
private:
    Enums::Lingue lingua;
    int NumeroSettimanale;

public:
    Rivista(const unsigned int identifier,
            std::string titolo,
            int AnnoPub,
            std::string descrizione,
            Enums::MediaGenre genere,
            std::string image_path,
            int pagine,
            std::string editore,
            std::string autore,
            Enums::Lingue lingua,
            int NumeroSettimanale);

    Media* clone() const;

    Enums::Lingue getLingua() const;
    Rivista& setLingua(const Enums::Lingue lingua);
    int getNumeroSettimanale() const;
    Rivista& setNumeroSettimanale(const int NumeroSettimanale);
    virtual void accept(class BVisitor& v);
    virtual void accept(class BConstVisitor& v) const;
};

#endif // RIVISTA_H
