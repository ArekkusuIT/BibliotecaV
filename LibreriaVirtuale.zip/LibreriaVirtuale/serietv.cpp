#include "serietv.h"

SerieTV::SerieTV(const unsigned int identifier,
                 std::string titolo,
                 int AnnoPub,
                 std::string descrizione,
                 Enums::MediaGenre genere,
                 std::string image_path,
                 std::string regista,
                 std::string studioProduzione,
                 std::string media_path,
                 Enums::AgeRating AgeRating,
                 int stagioni,
                 bool isInCorso):

    Multimedia(identifier, titolo, AnnoPub, descrizione, genere, image_path, regista, studioProduzione,media_path, AgeRating), stagioni(stagioni), isInCorso(isInCorso)
{}

int SerieTV::getStagioni() const{
    return stagioni;
}

SerieTV& SerieTV::setStagioni(const int stagioni){
    this->stagioni = stagioni;
    return *this;
}
bool SerieTV::getIsInCorso() const{
    return isInCorso;
}
SerieTV& SerieTV::setIsInCorso(const bool isInCorso){
    this->isInCorso = isInCorso;
    return *this;
}

void SerieTV::accept(class BVisitor& v){
    v.visit(*this);
}
void SerieTV::accept(class BConstVisitor& v) const {
    v.visit(*this);
}

Media* SerieTV::clone() const {
    return new SerieTV(*this);
}
