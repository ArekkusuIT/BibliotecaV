#ifndef LIBRO_H
#define LIBRO_H

#include <cartaceo.h>
#include "media.h"

class Libro: public Cartaceo {

private:
    std::string ISBN;
    Enums::Lingue lingua;

public:
    Libro (const unsigned int identifier,
          std::string titolo,
          int AnnoPub,
          std::string descrizione,
          Enums::MediaGenre genere,
          std::string image_path,
          int pagine,
          std::string editore,
          std::string autore,
          std::string ISBN,
          Enums::Lingue lingua);

    Media* clone() const;


    std::string getISBN() const;
    Libro& setISBN(const std::string ISBN);
    Enums::Lingue getLingua() const;
    Libro& setLingua(const Enums::Lingue lingua);
    virtual void accept(class BVisitor& v) ;
    virtual void accept(class BConstVisitor& v) const;
};

#endif // LIBRO_H
