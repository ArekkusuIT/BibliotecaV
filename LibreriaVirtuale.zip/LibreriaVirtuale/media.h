#ifndef MEDIA_H
#define MEDIA_H

#include <string>
#include "bvisitor.h"
#include "bconstvisitor.h"
#include "Enums/mediaenums.h"

class Media
{
private:
    unsigned int identifier;
    std::string titolo;
    int AnnoPub;
    std::string descrizione;
    Enums::MediaGenre genere;
    std::string image_path;
public:
    Media (const unsigned int identifier,
          std::string titolo,
          int AnnoPub,
          std::string descrizione,
          Enums::MediaGenre genere,
          std::string image_path);

    virtual ~Media();
    Media& setIdentifier(const unsigned int identifier);
    unsigned int getIdentifier() const;
    std::string getTitolo() const;
    Media& setTitolo(const std::string titolo);
    int getAnnoPub() const;
    Media& setAnnoPub(const int annoPub);
    std::string getDescrizione() const;
    Media& setDescrizione(const std::string descrizione);
    Enums::MediaGenre getGenere() const;
    Media& setGenere(const Enums::MediaGenre genere);
    std::string getImagePath() const;
    Media& setImagePath(const std::string image_path);
    virtual Media* clone() const = 0;

    virtual void accept(BVisitor& visitor) = 0;
    virtual void accept(BConstVisitor& visitor) const = 0;
};
#endif // MEDIA_H
