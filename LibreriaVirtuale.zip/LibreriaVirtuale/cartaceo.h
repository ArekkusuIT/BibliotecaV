#ifndef CARTACEO_H
#define CARTACEO_H

#include <media.h>
#include <string>
#include "Enums/mediaenums.h"

class Cartaceo : public Media
{

private:
    int pagine;
    std::string editore;
    std::string autore;

public:
    Cartaceo(const unsigned int identifier,
             std::string titolo,
             int AnnoPub,
             std::string descrizione,
             Enums::MediaGenre genere,
             std::string image_path,
             int pagine,
             std::string editore,
             std::string autore);

    virtual ~Cartaceo() = default;
    int getPagine() const;
    Cartaceo& setPagine(const int pagine);
    std::string getEditore() const;
    Cartaceo& setEditore(const std::string editore);
    std::string getAutore() const;
    Cartaceo& setAutore(const std::string autore);
};


#endif // CARTACEO_H
