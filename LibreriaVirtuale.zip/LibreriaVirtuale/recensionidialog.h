#ifndef RECENSIONIDIALOG_H
#define RECENSIONIDIALOG_H

#include <QDialog>
#include <QTableWidget>
#include "recensioni.h"

class RecensioniDialog : public QDialog
{
    Q_OBJECT
public:
    explicit RecensioniDialog(const std::vector<Recensioni>& recensioni, QWidget *parent = nullptr);

private:
    QTableWidget* table;
};


#endif // RECENSIONIDIALOG_H
