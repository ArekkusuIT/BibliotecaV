#include "reviewservice.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDebug>
#include <QNetworkReply>
#include <QUrl>



ReviewService::ReviewService(QObject* parent) : QObject(parent), manager(new QNetworkAccessManager(this)) {}

void ReviewService::fetchRecensioni(const std::string& titolo) {
    QString url = QString("http://www.omdbapi.com/?t=%1&apikey=d985ae41")
    .arg(QString::fromStdString(titolo).replace(" ", "+"));

    QNetworkRequest request;
    request.setUrl(QUrl(url));
    QNetworkReply* reply = manager->get(request);
    connect(reply, &QNetworkReply::finished, this, [=]() {
        std::vector<Recensioni> recensioni;

        if (reply->error() != QNetworkReply::NoError) {
            qWarning() << "Errore nella richiesta:" << reply->errorString();
            emit recensioniPronte(recensioni);
            reply->deleteLater();
            return;
        }

        QByteArray response = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(response);

        if (doc.isObject()) {
            QJsonObject obj = doc.object();

            if (obj.contains("Ratings")) {
                QJsonArray ratings = obj["Ratings"].toArray();
                for (const auto& rating : ratings) {
                    if (rating.isObject()) {
                        QJsonObject ratingObj = rating.toObject();
                        recensioni.emplace_back(
                            ratingObj["Source"].toString().toStdString(),
                            ratingObj["Value"].toString().toStdString()
                            );
                    }
                }
            }

            // Se non ci sono recensioni, mostra un messaggio
            if (recensioni.empty()) {
                recensioni.emplace_back("Nessuna recensione", "Trovata");
            }
        }

        emit recensioniPronte(recensioni);
        reply->deleteLater();
    });
}
