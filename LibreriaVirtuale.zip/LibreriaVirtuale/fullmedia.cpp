#include "fullmedia.h"


#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QPixmap>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>
#include <QDebug>
#include <QApplication>
#include <QTimer>
#include <QMovie>
#include "QFileInfo"
#include "QDir"

#include "Enums/enumsconversion.h"
#include "libro.h"
#include "rivista.h"
#include "film.h"
#include "serietv.h"
#include "reviewservice.h"

FullMedia::FullMedia(QWidget* parent)
    : QWidget(parent)
{
    mainLayout = new QVBoxLayout(this);
    detailsLayout = new QVBoxLayout();
    buttonLayout = new QHBoxLayout();


    titoloLabel = new QLabel(this);
    identifierLabel = new QLabel(this);
    editButton = new QPushButton(QIcon(":/icons/edit.png"), "Modifica");
    deleteButton = new QPushButton(QIcon(":/icons/delete.png"), "Elimina");

    connect(editButton, &QPushButton::clicked, this, &FullMedia::onClickedEditButton);
    connect(deleteButton, &QPushButton::clicked, this, &FullMedia::onClickedDeleteButton);

    detailsLayout->addWidget(titoloLabel);
    detailsLayout->addWidget(identifierLabel);

    buttonLayout->addWidget(editButton);
    buttonLayout->addWidget(deleteButton);

    mainLayout->addLayout(detailsLayout);
    mainLayout->addLayout(buttonLayout);

    setLayout(mainLayout);
}

void FullMedia::clearLayout(QLayout* layout) {

   titoloLabel->clear();
    identifierLabel->clear();

    if(layout == nullptr) return;

    QLayoutItem* item;
    while ((item = layout->takeAt(0)) != nullptr) {
        if (item->widget()) {
            QWidget* widget = item->widget();
            if (widget != titoloLabel && widget != identifierLabel && 
                widget != editButton && widget != deleteButton) {
                widget->deleteLater();
            }
        } else if (item->layout()) {
            clearLayout(item->layout());
            delete item->layout();
        }
        delete item;
    }
}

void FullMedia::displayInfo(const Media& media) {
    clearLayout(detailsLayout);
    titoloLabel->setText("<b>Title:</b> " + QString::fromStdString(media.getTitolo()) + "   ");
    identifierLabel->setText("<b>ID:</b> " + QString::number(media.getIdentifier()));
    ID = media.getIdentifier();

    // Usa dynamic_cast per risolvere correttamente il tipo
    try {
        // Prova a fare il cast per ogni tipo specifico
        if (dynamic_cast<const Libro*>(&media)) {
            visit(*dynamic_cast<const Libro*>(&media));
        }
        else if (dynamic_cast<const Rivista*>(&media)) {
            visit(*dynamic_cast<const Rivista*>(&media));
        }
        else if (dynamic_cast<const Film*>(&media)) {
            visit(*dynamic_cast<const Film*>(&media));
        }
        else if (dynamic_cast<const SerieTV*>(&media)) {
            visit(*dynamic_cast<const SerieTV*>(&media));
        }
        else {
            QMessageBox::warning(this, "Errore", "Tipo di media non supportato");
        }
    }
    catch (const std::bad_cast& e) {
        QMessageBox::warning(this, "Errore", QString("Errore nel casting: ") + e.what());
    }
}


void FullMedia::onClickedEditButton(){
    if(identifierLabel->text().isEmpty()) {
        QMessageBox::warning(this, "Attenzione", "Nessun media selezionato.");
        return;
    }
    emit showEditWindow(ID);
}

void FullMedia::onClickedDeleteButton(){
    if(identifierLabel->text().isEmpty()) {
        QMessageBox::warning(this, "Attenzione", "Nessun media selezionato.");
        return;
    }
    emit deleteMedia(ID);
    clearLayout(detailsLayout);
    ID = -1;
}

void FullMedia::visit(const Libro& libro){
    QVBoxLayout* layoutBook = new QVBoxLayout();
    layoutBook->setAlignment(Qt::AlignCenter);

    QLabel* image = new QLabel(this);
    image->setMinimumSize(150, 200);
    image->setMaximumSize(150, 200);
    image->setAlignment(Qt::AlignCenter);
    image->setStyleSheet("border: 1px solid gray; background-color: #f0f0f0;");

    QString imagePath = QString::fromStdString(libro.getImagePath());

    if(!imagePath.isEmpty()){
        QPixmap pixmap;

        if(imagePath.startsWith(":")) {
            // Risorse Qt
            pixmap = QPixmap(imagePath);
        } else {
            // File system - converti percorso relativo in assoluto
            QFileInfo fileInfo(imagePath);
            if(fileInfo.isRelative()) {
                imagePath = QDir::currentPath() + "/" + imagePath;
            }
            pixmap = QPixmap(imagePath);
        }

        if(!pixmap.isNull()){
            image->setPixmap(pixmap.scaled(150, 200, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        } else {
            // Fallback a immagine predefinita
            QPixmap fallback(":/icons/default_cover.png");
            if(!fallback.isNull()) {
                image->setPixmap(fallback.scaled(150, 200, Qt::KeepAspectRatio, Qt::SmoothTransformation));
            } else {
                image->setText("Immagine non disponibile");
                image->setStyleSheet("border: 1px solid red; color: red; background-color: #ffeeee;");
            }
        }
    } else {
        // Nessun percorso specificato
        QPixmap defaultPixmap(":/icons/default_cover.png");
        if(!defaultPixmap.isNull()) {
            image->setPixmap(defaultPixmap.scaled(150, 200, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        } else {
            image->setText(" Nessuna copertina");
            image->setStyleSheet("border: 1px solid #ccc; color: #666; background-color: #f8f8f8;");
        }
    }


    layoutBook->addWidget(image);
    layoutBook->addStretch(1);

    QVBoxLayout* infoLayout = new QVBoxLayout();
    infoLayout->setAlignment(Qt::AlignLeft | Qt::AlignTop);


    identifierLabel = new QLabel();
    identifierLabel->setObjectName("<b>ID:</b> " + QString::number(libro.getIdentifier()));
    infoLayout->addWidget(identifierLabel);

    titoloLabel = new QLabel("<b>Titolo:</b> " + QString::fromStdString(libro.getTitolo()));
    infoLayout->addWidget(titoloLabel);

    QLabel* genereLabel = new QLabel("<b>Genere:</b> " + QString::fromStdString(Enums::mediaGenreToString(libro.getGenere())));
    infoLayout->addWidget(genereLabel);

    QLabel* autoreLabel = new QLabel("<b>Autore:</b> " + QString::fromStdString(libro.getAutore()));
    infoLayout->addWidget(autoreLabel);

    QLabel* yearLabel = new QLabel("<b>Anno di pubblicazione:</b> " + QString::number(libro.getAnnoPub()));
    infoLayout->addWidget(yearLabel);

    QLabel* isbnLabel = new QLabel("<b>ISBN:</b> " + QString::fromStdString(libro.getISBN()));
    infoLayout->addWidget(isbnLabel);

    QLabel* linguaLabel = new QLabel("<b>Lingua:</b> " + QString::fromStdString(Enums::lingueToString(libro.getLingua())));
    infoLayout->addWidget(linguaLabel);


    layoutBook->addLayout(infoLayout);
    layoutBook->addSpacing(10);

    QHBoxLayout* vbox = new QHBoxLayout(this);
    vbox->setAlignment(Qt::AlignCenter);

    QHBoxLayout* descrizioneLayout = new QHBoxLayout();
    descrizioneLayout->setAlignment(Qt::AlignLeft);

    QLabel* descrizioneLabel = new QLabel("Descrizione:");
    QPushButton* descrizioneButton = new QPushButton("Mostra");
    descrizioneButton->setIcon(QIcon(":/icons/Images_PAO/descrizione.png"));

    connect(descrizioneButton, &QPushButton::clicked, this, [this, libro]() {
        QMessageBox::information(this, "Descrizione", QString::fromStdString(libro.getDescrizione()));
    });

    descrizioneLayout->addWidget(descrizioneLabel);
    descrizioneLayout->addWidget(descrizioneButton);

    layoutBook->addLayout(descrizioneLayout);

    QPushButton* readButton = new QPushButton("Leggi");
    connect(readButton, &QPushButton::clicked, this, [this, libro]() {
        QMessageBox::information(this, "Leggi", QMessageBox::tr("Funzionalità di lettura non ancora implementata."));
    });
    vbox->addWidget(readButton);

    layoutBook->addLayout(vbox);
    detailsLayout->addLayout(layoutBook);

}

void FullMedia::visit(const Film& film){
    QVBoxLayout* layoutFilm = new QVBoxLayout();
    layoutFilm->setAlignment(Qt::AlignCenter);

    QLabel* image = new QLabel(this);
    if(!QString::fromStdString(film.getImagePath()).isEmpty()){
        QPixmap pixmap(QString::fromStdString(film.getImagePath()));
        if(!pixmap.isNull()){
            image->setPixmap(pixmap.scaled(QSize(150, 200), Qt::KeepAspectRatio, Qt::SmoothTransformation));
            image->setAlignment(Qt::AlignCenter);
        } else {
            image->setText("Immagine non disponibile");
        }
    }
    layoutFilm->addWidget(image);
    layoutFilm->addStretch(1);

    QVBoxLayout* infoLayout = new QVBoxLayout();
    infoLayout->setAlignment(Qt::AlignLeft | Qt::AlignTop);


    identifierLabel = new QLabel();
    identifierLabel->setObjectName("<b>ID:</b> " + QString::number(film.getIdentifier()));
    infoLayout->addWidget(identifierLabel);

    titoloLabel = new QLabel("<b>Titolo:</b> " + QString::fromStdString(film.getTitolo()));
    infoLayout->addWidget(titoloLabel);

    QLabel* genereLabel = new QLabel("<b>Genere:</b> " + QString::fromStdString(Enums::mediaGenreToString(film.getGenere())));
    infoLayout->addWidget(genereLabel);

    QLabel* registaLabel = new QLabel("<b>Regista:</b> " + QString::fromStdString(film.getRegista()));
    infoLayout->addWidget(registaLabel);

    QLabel* yearLabel = new QLabel("<b>Anno di pubblicazione:</b> " + QString::number(film.getAnnoPub()));
    infoLayout->addWidget(yearLabel);

    QLabel* durataLabel = new QLabel("<b>Durata:</b> " + QString::number(film.getDurataMinuti()) + " minuti");
    infoLayout->addWidget(durataLabel);

    QLabel* qualitaLabel = new QLabel("<b>Qualità Video:</b> " + QString::fromStdString(Enums::videoQualityToString(film.getQualitaVideo())));
    infoLayout->addWidget(qualitaLabel);

    layoutFilm->addLayout(infoLayout);
    layoutFilm->addSpacing(10);

    QHBoxLayout* vbox = new QHBoxLayout(this);
    vbox->setAlignment(Qt::AlignCenter);

    QHBoxLayout* descrizioneLayout = new QHBoxLayout();
    descrizioneLayout->setAlignment(Qt::AlignLeft);

    QLabel* descrizioneLabel = new QLabel("Descrizione:");
    QPushButton* descrizioneButton = new QPushButton("Mostra");
    descrizioneButton->setIcon(QIcon(":/icons/Images_PAO/descrizione.png"));

    connect(descrizioneButton, &QPushButton::clicked, this, [this, film]() {
        QMessageBox::information(this, "Descrizione", QString::fromStdString(film.getDescrizione()));
    });

    descrizioneLayout->addWidget(descrizioneLabel);
    descrizioneLayout->addWidget(descrizioneButton);

    layoutFilm->addLayout(descrizioneLayout);



    QPushButton* playButton = new QPushButton (QIcon(":/icons/Images_PAO/play_button_icon.png"), "Trailer");
    connect(playButton, &QPushButton::clicked, this, [this, film]() {
        QMessageBox::information(this, "Leggi", QMessageBox::tr("Funzionalità di visione Trailer non ancora implementata."));
    });
    vbox->addWidget(playButton);

    vbox->addWidget(playButton);
    layoutFilm->addLayout(vbox);
    detailsLayout->addLayout(layoutFilm);

    QPushButton* bottoneRecensioni = new QPushButton("Mostra Recensioni");
    connect(bottoneRecensioni, &QPushButton::clicked, this, [=]() {
        onRecensioniButtonClicked(film.getTitolo());
    });
    vbox->addWidget(bottoneRecensioni);

    layoutFilm->addLayout(vbox);
    detailsLayout->addLayout(layoutFilm);


}

void FullMedia::visit(const Rivista& rivista){
    QVBoxLayout* layoutRivista = new QVBoxLayout();
    layoutRivista->setAlignment(Qt::AlignCenter);

    QLabel* image = new QLabel(this);
    if(!QString::fromStdString(rivista.getImagePath()).isEmpty()){
        QPixmap pixmap(QString::fromStdString(rivista.getImagePath()));
        if(!pixmap.isNull()){
            image->setPixmap(pixmap.scaled(QSize(150, 200), Qt::KeepAspectRatio, Qt::SmoothTransformation));
            image->setAlignment(Qt::AlignCenter);
        } else {
            image->setText("Immagine non disponibile");
        }
    }
    layoutRivista->addWidget(image);
    layoutRivista->addStretch(1);

    QVBoxLayout* infoLayout = new QVBoxLayout();
    infoLayout->setAlignment(Qt::AlignLeft | Qt::AlignTop);


    identifierLabel = new QLabel();
    identifierLabel->setObjectName("<b>ID:</b> " + QString::number(rivista.getIdentifier()));
    infoLayout->addWidget(identifierLabel);

    titoloLabel = new QLabel("<b>Titolo:</b> " + QString::fromStdString(rivista.getTitolo()));
    infoLayout->addWidget(titoloLabel);

    QLabel* genereLabel = new QLabel("<b>Genere:</b> " + QString::fromStdString(Enums::mediaGenreToString(rivista.getGenere())));
    infoLayout->addWidget(genereLabel);

    QLabel* autoreLabel = new QLabel("<b>Autore:</b> " + QString::fromStdString(rivista.getAutore()));
    infoLayout->addWidget(autoreLabel);

    QLabel* yearLabel = new QLabel("<b>Anno di pubblicazione:</b> " + QString::number(rivista.getAnnoPub()));
    infoLayout->addWidget(yearLabel);

    QLabel* linguaLabel = new QLabel("<b>Lingua:</b> " + QString::fromStdString(Enums::lingueToString(rivista.getLingua())));
    infoLayout->addWidget(linguaLabel);

    layoutRivista->addLayout(infoLayout);
    layoutRivista->addSpacing(10);

    QHBoxLayout* vbox = new QHBoxLayout(this);
    vbox->setAlignment(Qt::AlignCenter);

    QHBoxLayout* descrizioneLayout = new QHBoxLayout();
    descrizioneLayout->setAlignment(Qt::AlignLeft);

    QLabel* descrizioneLabel = new QLabel("Descrizione:");
    QPushButton* descrizioneButton = new QPushButton("Mostra");
    descrizioneButton->setIcon(QIcon(":/icons/Images_PAO/descrizione.png"));

    connect(descrizioneButton, &QPushButton::clicked, this, [this, rivista]() {
        QMessageBox::information(this, "Descrizione", QString::fromStdString(rivista.getDescrizione()));
    });

    descrizioneLayout->addWidget(descrizioneLabel);
    descrizioneLayout->addWidget(descrizioneButton);

    layoutRivista->addLayout(descrizioneLayout);

    QPushButton* readButton = new QPushButton("Leggi");
    connect(readButton, &QPushButton::clicked, this, [this, rivista]() {
        QMessageBox::information(this, "Trailer", QMessageBox::tr("Funzionalità di lettura non ancora implementata."));
    });
    vbox->addWidget(readButton);

    layoutRivista->addLayout(vbox);
    detailsLayout->addLayout(layoutRivista);
}

void FullMedia::visit(const SerieTV& serieTV){
    QVBoxLayout* layoutSerie = new QVBoxLayout();
    layoutSerie->setAlignment(Qt::AlignCenter);

    QLabel* image = new QLabel(this);
    if(!QString::fromStdString(serieTV.getImagePath()).isEmpty()){
        QPixmap pixmap(QString::fromStdString(serieTV.getImagePath()));
        if(!pixmap.isNull()){
            image->setPixmap(pixmap.scaled(QSize(150, 200), Qt::KeepAspectRatio, Qt::SmoothTransformation));
            image->setAlignment(Qt::AlignCenter);
        } else {
            image->setText("Immagine non disponibile");
        }
    }
    layoutSerie->addWidget(image);
    layoutSerie->addStretch(1);

    QVBoxLayout* infoLayout = new QVBoxLayout();
    infoLayout->setAlignment(Qt::AlignLeft | Qt::AlignTop);


    identifierLabel = new QLabel();
    identifierLabel->setObjectName("<b>ID:</b> " + QString::number(serieTV.getIdentifier()));
    infoLayout->addWidget(identifierLabel);

    titoloLabel = new QLabel("<b>Titolo:</b> " + QString::fromStdString(serieTV.getTitolo()));
    infoLayout->addWidget(titoloLabel);

    QLabel* genereLabel = new QLabel("<b>Genere:</b> " + QString::fromStdString(Enums::mediaGenreToString(serieTV.getGenere())));
    infoLayout->addWidget(genereLabel);

    QLabel* registaLabel = new QLabel("<b>Regista:</b> " + QString::fromStdString(serieTV.getRegista()));
    infoLayout->addWidget(registaLabel);

    QLabel* yearLabel = new QLabel("<b>Anno di pubblicazione:</b> " + QString::number(serieTV.getAnnoPub()));
    infoLayout->addWidget(yearLabel);

    QLabel* stagioniLabel = new QLabel("<b>Numero di stagioni:</b> " + QString::number(serieTV.getStagioni()));
    infoLayout->addWidget(stagioniLabel);

    QLabel* statoLabel = new QLabel("<b>Stato:</b> " + QString::fromStdString(serieTV.getIsInCorso() ? "In corso" : "Conclusa"));
    infoLayout->addWidget(statoLabel);

    layoutSerie->addLayout(infoLayout);
    layoutSerie->addSpacing(10);

    QHBoxLayout* vbox = new QHBoxLayout(this);
    vbox->setAlignment(Qt::AlignCenter);

    QHBoxLayout* descrizioneLayout = new QHBoxLayout();
    descrizioneLayout->setAlignment(Qt::AlignLeft);

    QLabel* descrizioneLabel = new QLabel("Descrizione:");
    QPushButton* descrizioneButton = new QPushButton("Mostra");
    descrizioneButton->setIcon(QIcon(":/icons/Images_PAO/descrizione.png"));

    connect(descrizioneButton, &QPushButton::clicked, this, [this, serieTV]() {
        QMessageBox::information(this, "Descrizione", QString::fromStdString(serieTV.getDescrizione()));
    });

    descrizioneLayout->addWidget(descrizioneLabel);
    descrizioneLayout->addWidget(descrizioneButton);

    layoutSerie->addLayout(descrizioneLayout);

    QPushButton* playButton = new QPushButton (QIcon(":/icons/Images_PAO/play_button_icon.png"), "Trailer");
    connect(playButton, &QPushButton::clicked, this, [this, serieTV]() {
        QMessageBox::information(this, "Trailer", QMessageBox::tr("Funzionalità di visione Trailer non ancora implementata."));
    });
    vbox->addWidget(playButton);

    layoutSerie->addLayout(vbox);
    detailsLayout->addLayout(layoutSerie);

    QPushButton* bottoneRecensioni = new QPushButton("Mostra Recensioni");
    connect(bottoneRecensioni, &QPushButton::clicked, this, [=]() {
        onRecensioniButtonClicked(serieTV.getTitolo());
    });

    vbox->addWidget(bottoneRecensioni);

    layoutSerie->addLayout(vbox);
    detailsLayout->addLayout(layoutSerie);

}

void FullMedia::onRecensioniButtonClicked(const std::string& titolo) {
    ReviewService* reviewService = new ReviewService(this);
    connect(reviewService, &ReviewService::recensioniPronte, this, [=](const std::vector<Recensioni>& recensioni) {
    QString recensioniText;
    for (const auto& recensione : recensioni) {
        recensioniText += "<b>Fonte:</b> " + QString::fromStdString(recensione.getFonte()) + "<br>";
        recensioniText += "<b>Voto:</b> " + QString::fromStdString(recensione.getValutazione()) + "<br>";

    }    if (recensioniText.isEmpty()) {
        recensioniText = "Nessuna recensione disponibile.";
    }
    QMessageBox msgBox;
    msgBox.setWindowTitle("Recensioni");
    msgBox.setTextFormat(Qt::RichText);
    msgBox.setText(recensioniText);
    msgBox.exec();
    reviewService->deleteLater(); // Pulisce l'oggetto dopo l'uso
    });

    reviewService->fetchRecensioni(titolo);
}





