#ifndef MEDIAENUMS_H
#define MEDIAENUMS_H

#pragma once

namespace Enums {

enum class MediaGenre {
    Fantascienza,
    Fantasy,
    Horror,
    Commedia,
    Drammatico,
    Documentario,
    Thriller,
    Romantico,
    Avventura,
    Animazione,
    Storico,
    Biografico,
    Musicale,
    Guerra,
    Western
};

enum class AgeRating {
    G,      // General Audience
    PG,     // Parental Guidance Suggested
    PG13,   // Parents Strongly Cautioned
    R,      // Restricted
    NC17    // Adults Only
};

enum class VideoQuality {
    SD,     // Standard Definition
    HD,     // High Definition
    FHD,    // Full High Definition
    UHD,    // Ultra High Definition (4K)
    HDR     // High Dynamic Range
};

enum class Lingue{
    Italiano,
    Inglese,
    Spagnolo,
    Francese,
    Tedesco,
    Cinese,
    Giapponese,
    Russo,
    Arabo,
    Portoghese,
    Altro
};
}
#endif // MEDIAENUMS_H
